<?php
/**
 * Delta queue, WooCommerce hooks and batched catalogue sync.
 *
 * @package VigentWoo
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

class Vigent_Woo_Sync {
        /** Release this file shipped in; vigent-woo.php will not boot a mix of releases. */
        const RELEASE = '5.2.1';

        const DELTA_QUEUE_OPTION = 'vigent_woo_delta_queue';
        const SYNC_STATE_OPTION  = 'vigent_woo_sync_state';
        const QUEUE_LOCK_OPTION  = 'vigent_woo_delta_queue_lock';
        const FLUSH_LOCK_OPTION  = 'vigent_woo_delta_flush_lock';
        const MAX_QUEUE_SIZE     = 5000;
        const MAX_BATCH_SIZE     = 50;
        const TRACKING_BACKFILL_BATCH_SIZE = 200;
        const TRACKING_BACKFILL_STATE_OPTION = 'vigent_woo_tracking_backfill_state';
        const TRACKING_BACKFILL_LOCK_OPTION  = 'vigent_woo_tracking_backfill_lock';
        const PRODUCT_RESYNC_STATE_OPTION = 'vigent_woo_product_resync_state';
        const PRODUCT_RESYNC_LOCK_OPTION  = 'vigent_woo_product_resync_lock';
        /** Ignore repeated resend requests for this long, so a server fault cannot hammer the store. */
        const PRODUCT_RESYNC_MIN_INTERVAL = 900;
        const PRODUCT_RESYNC_MAX_ATTEMPTS = 6;
        /**
         * Maximum number of ORDERS to sync during a full push.
         *
         * Orders are historical and rarely useful past a certain age, so we still
         * cap them at MAX_ORDERS_TO_SYNC to keep the panel DB bounded and the
         * sync wizard fast. The Vigent panel also enforces its own retention
         * (deletes oldest orders when a workspace exceeds 2000).
         *
         * IMPORTANT: This cap applies to ORDERS ONLY. Customers are no longer
         * capped — every customer with at least one paid order is synced, even
         * if the store has tens of thousands of them. The product owner asked
         * for this explicitly: "محدودیت نداره" (no limit on customers).
         */
        const MAX_ORDERS_TO_SYNC = 1000;
        /**
         * Vigent answers a body larger than 4MB with HTTP 413. Fifty products with
         * long descriptions can pass that, and the old code retried the very same
         * oversized batch every five minutes forever, so the queue never drained.
         * Batches are now split to stay well under the server limit.
         */
        const MAX_BATCH_BYTES    = 2097152;
        /**
         * A change that the server keeps rejecting (permanent 4xx, conflicting
         * delivery, oversized single product) used to sit at the head of the queue
         * and block every later change. After this many failed flushes it is
         * dead-lettered and reported on the settings screen; a full push recovers it.
         */
        const MAX_DELTA_ATTEMPTS = 12;
        /** Post meta holding a fingerprint of the product payload Vigent last accepted. */
        const PRODUCT_HASH_META = '_vigent_woo_sync_hash';
        /**
         * Some hosts run WP-Cron only about once an hour, and one 50-event batch per
         * run never catches up with a store whose tools re-save thousands of products
         * an hour. A scheduled flush keeps sending batches for this many seconds.
         */
        const FLUSH_TIME_BUDGET = 20;
        /** How long a single (manual) flush may spend looking past unchanged products. */
        const FLUSH_SINGLE_BUDGET = 10;
        /** One-off cron event that continues a scheduled flush which ran out of time. */
        const FLUSH_MORE_HOOK = 'vigent_woo_delta_flush_more';
        /**
         * Order statuses that count as "successful" (paid) for the
         * customer-filter. A customer is synced to Vigent only if they
         * have at least one shop_order in one of these statuses.
         *
         *   • completed  — order fulfilled & closed
         *   • processing — payment received, being prepared/shipped
         *
         * Excluded: pending, on-hold, cancelled, refunded, failed — these
         * represent abandoned or unsuccessful checkouts and the customer
         * has not actually paid yet.
         */
        const SUCCESSFUL_ORDER_STATUSES = array( 'completed', 'processing' );
        /**
         * Order statuses that are SYNCED to Vigent.
         *
         * This is the inverse of the "excluded" list — we sync every order
         * status EXCEPT the ones the product owner explicitly asked to skip:
         *
         *   • cancelled — the customer (or admin) explicitly cancelled the
         *     order. There is nothing to track, no shipping to follow up, and
         *     no payment to chase. Syncing these would just pollute the
         *     agent's order list with dead rows.
         *
         * Everything else is sent so the agent can answer "where is my
         * order?" / "what's my order status?" / "why is my payment on hold?"
         * for ALL active and historical orders the customer might ask about:
         *
         *   • pending     — checkout started, awaiting payment
         *   • on-hold     — payment received but stock/awaiting manual review
         *   • processing — payment received, being prepared/shipped
         *   • completed   — fulfilled & closed
         *   • refunded    — money returned to the customer (the customer
         *                  might still ask "where is my refund?" so we keep
         *                  these for historical context)
         *   • failed      — payment attempted and declined (the customer
         *                  might still ask "why did my payment fail?")
         *
         * Note: shop_order_refund posts are already filtered out separately
         * via `type => shop_order` in the wc_get_orders() args — that's a
         * different concept (a separate WC post type) vs the `cancelled`
         * order status (a status on a normal shop_order).
         *
         * The status names use the "wc-" prefix form because that's what
         * wc_get_order_statuses() returns as array keys. We compare against
         * the same form everywhere (count_items, sync_batch, get_order_stats,
         * queue_order) so the array_diff + in_array checks all line up.
         * wc_get_orders() accepts both forms ("cancelled" and "wc-cancelled")
         * so passing either works in the status filter.
         */
        const EXCLUDED_ORDER_STATUSES = array( 'wc-cancelled' );
        /**
         * Transient key + TTL for the cached list of customer IDs that
         * have ≥1 paid order. We cache it so the bulk-sync wizard doesn't
         * re-run the orders query on every page (50 customers per page ×
         * N pages would be expensive on a busy store).
         */
        const CUSTOMERS_WITH_ORDERS_CACHE_KEY = 'vigent_woo_customers_with_orders';
        const CUSTOMERS_WITH_ORDERS_CACHE_TTL = 21600; // 6 hours — paying customers rarely change, and recomputing requires fetching every paid order

        private static $instance = null;

        /** Products updated during this request, checked once when it ends. */
        private $pending_products = array();
        /** Set once the end-of-request check has run; later updates are checked at once. */
        private $pending_drained = false;
        /** Seconds this PHP process already spent in scheduled flushes. */
        private $flush_seconds_spent = 0.0;

        public static function instance() {
                if ( null === self::$instance ) {
                        self::$instance = new self();
                }
                return self::$instance;
        }

        private function __construct() {
                add_action( 'woocommerce_new_product', array( $this, 'on_product_new' ), 10, 2 );
                add_action( 'woocommerce_update_product', array( $this, 'on_product_update' ), 10, 2 );
                add_action( 'woocommerce_new_product_variation', array( $this, 'on_product_variation_change' ), 10, 2 );
                add_action( 'woocommerce_update_product_variation', array( $this, 'on_product_variation_change' ), 10, 2 );
                add_action( 'woocommerce_trash_product', array( $this, 'on_product_delete' ) );
                add_action( 'before_delete_post', array( $this, 'on_product_delete' ) );

                add_action( 'woocommerce_new_order', array( $this, 'on_order_new' ), 10, 2 );
                add_action( 'woocommerce_update_order', array( $this, 'on_order_update' ), 10, 2 );
                add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 10, 4 );
                // A number of Iranian tracking meta boxes save their custom field
                // directly with update_post_meta() and do not call WC_Order::save().
                // In that path WooCommerce's update-order hook never fires. Watching
                // post-meta changes ensures the latest order is materialized by the
                // normal five-minute delta flush without requiring a status change.
                add_action( 'added_post_meta', array( $this, 'on_order_meta_change' ), 20, 4 );
                add_action( 'updated_post_meta', array( $this, 'on_order_meta_change' ), 20, 4 );
                add_action( 'deleted_post_meta', array( $this, 'on_order_meta_change' ), 20, 4 );
                add_action( 'woocommerce_order_note_added', array( $this, 'on_order_note_added' ), 20, 2 );

                // Customer hooks — fire on:
                //   • user_register / profile_update       → covers WP-level signups + edits.
                //   • woocommerce_create_customer          → covers WC programmatic creation.
                //   • woocommerce_save_account_details      → customer editing their account page.
                //   • personal_options_update / edit_user_profile_update → admin editing the user.
                //   • woocommerce_customer_save_address     → customer updating their billing address.
                // We attach to ALL of them because different hosting setups fire different
                // hooks depending on whether the customer was created via the admin UI,
                // the checkout form, the my-account page, or programmatically.
                add_action( 'user_register', array( $this, 'on_customer_change' ) );
                add_action( 'profile_update', array( $this, 'on_customer_change' ), 10, 2 );
                add_action( 'personal_options_update', array( $this, 'on_customer_change' ) );
                add_action( 'edit_user_profile_update', array( $this, 'on_customer_change' ) );
                add_action( 'woocommerce_create_customer', array( $this, 'on_customer_change' ) );
                add_action( 'woocommerce_save_account_details', array( $this, 'on_customer_change' ) );
                add_action( 'woocommerce_customer_save_address', array( $this, 'on_customer_change' ) );

                add_action( 'vigent_woo_enqueue_delta_retry', array( $this, 'enqueue_delta' ), 10, 4 );
        }

        private function core() {
                return Vigent_Woo_Core::instance();
        }

        public function on_product_new( $product_id, $product = null ) {
                $this->queue_product( $product_id, 'product.created' );
        }

        public function on_product_update( $product_id, $product = null ) {
                $this->queue_product( $product_id, 'product.updated' );
        }

        public function on_product_variation_change( $variation_id, $variation = null ) {
                if ( ! $variation && function_exists( 'wc_get_product' ) ) {
                        $variation = wc_get_product( $variation_id );
                }
                $parent_id = $variation && method_exists( $variation, 'get_parent_id' ) ? $variation->get_parent_id() : wp_get_post_parent_id( $variation_id );
                if ( $parent_id ) {
                        $this->queue_product( $parent_id, 'product.updated' );
                }
        }

        private function queue_product( $product_id, $topic ) {
                $product_id = absint( $product_id );
                if ( ! $product_id || ! $this->core()->sync_products_enabled() ) {
                        return;
                }
                if ( wp_is_post_revision( $product_id ) || wp_is_post_autosave( $product_id ) ) {
                        return;
                }
                // Stock and price tools re-save thousands of products an hour without
                // changing anything, and every queued no-op pushed real changes further
                // back. An update is checked once, when the request ends (after WooCommerce
                // has saved every variation and any late meta), and queued only when what
                // Vigent would receive differs from what it last accepted.
                if ( 'product.updated' === $topic ) {
                        if ( $this->pending_drained ) {
                                $this->queue_product_if_changed( $product_id );
                                return;
                        }
                        if ( empty( $this->pending_products ) ) {
                                // After WooCommerce's own deferred parent sync (priority 10).
                                add_action( 'shutdown', array( $this, 'queue_pending_products' ), 20 );
                        }
                        $this->pending_products[ $product_id ] = true;
                        return;
                }
                $this->enqueue_delta( 'product', $product_id, $topic );
        }

        /** End-of-request half of queue_product(). */
        public function queue_pending_products() {
                while ( ! empty( $this->pending_products ) ) {
                        reset( $this->pending_products );
                        $product_id = (int) key( $this->pending_products );
                        unset( $this->pending_products[ $product_id ] );
                        $this->queue_product_if_changed( $product_id );
                }
                $this->pending_drained = true;
        }

        private function queue_product_if_changed( $product_id ) {
                if ( ! $this->core()->sync_products_enabled() ) {
                        return false;
                }
                try {
                        $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
                        if ( $product && $this->product_matches_last_sync( $product_id, $this->product_payload_hash( $this->core()->product_to_payload( $product ) ) ) ) {
                                return false;
                        }
                } catch ( \Throwable $e ) {
                        // Unsure means send: the flush builds the payload again anyway.
                        $this->core()->debug_log( 'queue_product HASH_FAIL', array( 'id' => $product_id, 'error' => $e->getMessage() ) );
                }
                return $this->enqueue_delta( 'product', $product_id, 'product.updated' );
        }

        /**
         * Fingerprint of a product payload. The modified date moves on every save,
         * even one that changes nothing, so it is left out. The connection URL is
         * mixed in so that connecting to another workspace sends everything again.
         */
        private function product_payload_hash( $payload ) {
                if ( ! is_array( $payload ) || empty( $payload ) ) {
                        return '';
                }
                unset( $payload['date_modified'], $payload['date_modified_gmt'] );
                $encoded = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                if ( false === $encoded ) {
                        return '';
                }
                $settings = get_option( VIGENT_WOO_OPTION, array() );
                $url      = is_array( $settings ) && isset( $settings['webhook_url'] ) ? (string) $settings['webhook_url'] : '';
                return md5( $url . '|' . $encoded );
        }

        /** Whether Vigent already holds exactly this product payload. */
        private function product_matches_last_sync( $product_id, $hash ) {
                if ( '' === $hash ) {
                        return false;
                }
                $stored = get_post_meta( $product_id, self::PRODUCT_HASH_META, true );
                return is_string( $stored ) && '' !== $stored && hash_equals( $stored, $hash );
        }

        /** Record what Vigent accepted, so a later save that changes nothing is not sent again. */
        private function remember_product_hashes( $events, $hashes ) {
                foreach ( $events as $key => $event ) {
                        if ( 0 !== strpos( (string) $key, 'product:' ) ) {
                                continue;
                        }
                        $product_id = absint( substr( (string) $key, 8 ) );
                        if ( ! $product_id ) {
                                continue;
                        }
                        if ( isset( $event['topic'] ) && 'product.deleted' === $event['topic'] ) {
                                // A restored product is sent again on its next save.
                                delete_post_meta( $product_id, self::PRODUCT_HASH_META );
                        } elseif ( ! empty( $hashes[ $key ] ) ) {
                                update_post_meta( $product_id, self::PRODUCT_HASH_META, $hashes[ $key ] );
                        }
                }
        }

        public function on_product_delete( $post_id ) {
                $post_id = absint( $post_id );
                if ( ! $post_id || ! $this->core()->has_wc() || ! $this->core()->sync_products_enabled() ) {
                        return;
                }
                $post_type = get_post_type( $post_id );
                if ( 'product_variation' === $post_type ) {
                        $parent_id = wp_get_post_parent_id( $post_id );
                        if ( $parent_id ) {
                                $this->queue_product( $parent_id, 'product.updated' );
                        }
                        return;
                }
                if ( 'product' !== $post_type ) {
                        return;
                }

                $product = wc_get_product( $post_id );
                $payload = array( 'id' => $post_id );
                if ( $product ) {
                        $payload['sku']  = $product->get_sku();
                        $payload['name'] = $product->get_name();
                }
                $this->enqueue_delta( 'product', $post_id, 'product.deleted', $payload );
        }

        public function on_order_new( $order_id, $order = null ) {
                $this->queue_order( $order_id, 'order.created' );
        }

        public function on_order_update( $order_id, $order = null ) {
                $this->queue_order( $order_id, 'order.updated' );
        }

        /** Queue legacy/CPT orders when a tracking plugin writes meta directly. */
        public function on_order_meta_change( $meta_id, $object_id, $meta_key, $meta_value ) {
                $object_id = absint( $object_id );
                if ( ! $object_id || ! $this->core()->sync_orders_enabled() ) {
                        return;
                }
                if ( function_exists( 'get_post_type' ) && 'shop_order' !== get_post_type( $object_id ) ) {
                        return;
                }
                $this->queue_order( $object_id, 'order.updated' );
        }

        /** Order notes are another common place for Iranian shops to enter a code. */
        public function on_order_note_added( $note_id, $order ) {
                if ( is_object( $order ) && method_exists( $order, 'get_id' ) ) {
                        $this->queue_order( $order->get_id(), 'order.updated' );
                }
        }

        /** Compatibility callback for the one-off event scheduled by v4.3.9. */
        public function backfill_recent_order_tracking() {
                return $this->backfill_all_order_tracking();
        }

        /**
         * Progressively inspect every non-cancelled order for optional tracking.
         *
         * One run handles at most 200 orders and schedules the next page shortly
         * afterwards. This keeps memory/request time bounded on large stores and is
         * compatible with both legacy order posts and HPOS through wc_get_orders().
         * Lightweight `order.tracking.updated` events only repair existing Vigent
         * rows, so the pass cannot bypass plan limits or create unwanted history.
         */
        public function backfill_all_order_tracking() {
                if ( ! $this->core()->is_configured() || ! $this->core()->has_wc() || ! $this->core()->sync_orders_enabled() ) {
                        return array( 'done' => false, 'processed' => 0 );
                }
                if ( ! $this->acquire_lock( self::TRACKING_BACKFILL_LOCK_OPTION, 180 ) ) {
                        $this->schedule_tracking_backfill( 60 );
                        return array( 'done' => false, 'processed' => 0 );
                }

                $state = get_option( self::TRACKING_BACKFILL_STATE_OPTION, array() );
                if ( ! is_array( $state ) ) {
                        $state = array();
                }
                $page      = max( 1, isset( $state['page'] ) ? absint( $state['page'] ) : 1 );
                $processed = isset( $state['processed'] ) ? absint( $state['processed'] ) : 0;
                $args = array(
                        'limit'    => self::TRACKING_BACKFILL_BATCH_SIZE,
                        'page'     => $page,
                        'paginate' => true,
                        'orderby'  => 'ID',
                        'order'    => 'ASC',
                        'return'   => 'objects',
                        'type'     => 'shop_order',
                );
                if ( function_exists( 'wc_get_order_statuses' ) ) {
                        $included = array_values( array_diff( array_keys( wc_get_order_statuses() ), self::EXCLUDED_ORDER_STATUSES ) );
                        if ( ! empty( $included ) ) {
                                $args['status'] = $included;
                        }
                }

                $result    = wc_get_orders( $args );
                $orders    = is_object( $result ) && isset( $result->orders ) ? $result->orders : ( is_array( $result ) ? $result : array() );
                $total     = is_object( $result ) && isset( $result->total ) ? absint( $result->total ) : count( $orders );
                $max_pages = is_object( $result ) && isset( $result->max_num_pages ) ? max( 1, absint( $result->max_num_pages ) ) : 1;
                $events = array();
                foreach ( $orders as $order ) {
                        if ( ! is_a( $order, 'WC_Order' )
                                || 'shop_order_refund' === $order->get_type()
                                || $this->is_order_excluded( $order->get_status() ) ) {
                                continue;
                        }
                        $payload = $this->core()->order_tracking_to_payload( $order );
                        if ( ! empty( $payload ) ) {
                                $events[] = $this->make_event( 'order.tracking.updated', $payload );
                        }
                }

                $all_ok     = true;
                $last_error = '';
                foreach ( $this->chunk_events_by_budget( $events ) as $chunk ) {
                        $send = $this->core()->send_batch_events( array_values( $chunk ), false );
                        if ( empty( $send['success'] ) ) {
                                $all_ok     = false;
                                $last_error = isset( $send['body'] ) ? wp_strip_all_tags( (string) $send['body'] ) : __( 'خطای نامشخص', 'vigent-woo' );
                                break;
                        }
                }

                if ( ! $all_ok ) {
                        $state['status']       = 'retrying';
                        $state['page']         = $page;
                        $state['processed']    = $processed;
                        $state['total']        = $total;
                        $state['last_error']   = substr( $last_error, 0, 500 );
                        $state['last_attempt'] = current_time( 'mysql' );
                        update_option( self::TRACKING_BACKFILL_STATE_OPTION, $state, false );
                        $this->release_lock( self::TRACKING_BACKFILL_LOCK_OPTION );
                        $this->schedule_tracking_backfill( 300 );
                        return array( 'done' => false, 'processed' => $processed, 'error' => $last_error );
                }

                $processed += count( $orders );
                $done = empty( $orders ) || $page >= $max_pages || count( $orders ) < self::TRACKING_BACKFILL_BATCH_SIZE;
                $state = array(
                        'status'       => $done ? 'complete' : 'running',
                        'page'         => $done ? $page : $page + 1,
                        'processed'    => $processed,
                        'total'        => $total,
                        'last_error'   => '',
                        'last_attempt' => current_time( 'mysql' ),
                        'finished_at'  => $done ? current_time( 'mysql' ) : '',
                );
                update_option( self::TRACKING_BACKFILL_STATE_OPTION, $state, false );
                $this->release_lock( self::TRACKING_BACKFILL_LOCK_OPTION );

                $this->core()->debug_log( 'tracking_backfill PAGE', array(
                        'page'      => $page,
                        'processed' => $processed,
                        'total'     => $total,
                        'done'      => $done,
                ) );
                if ( ! $done ) {
                        $this->schedule_tracking_backfill( 20 );
                }
                return array( 'done' => $done, 'processed' => $processed, 'total' => $total );
        }

        /** Schedule the next repair page without creating duplicate cron events. */
        private function schedule_tracking_backfill( $delay ) {
                if ( ! wp_next_scheduled( 'vigent_woo_tracking_backfill' ) ) {
                        wp_schedule_single_event( time() + max( 10, absint( $delay ) ), 'vigent_woo_tracking_backfill' );
                }
        }

        /**
         * Queue a background push of every published product.
         *
         * Vigent asks for this when products it refused earlier (plan limit) fit
         * now — typically right after a plan upgrade — so the shop owner no longer
         * has to reconnect the plugin to get the rest of the catalog across.
         *
         * @return bool Whether a resend is running or was just scheduled.
         */
        public function request_product_resync( $source = '' ) {
                if ( ! $this->core()->is_configured() || ! $this->core()->has_wc() || ! $this->core()->sync_products_enabled() ) {
                        return false;
                }
                $state = get_option( self::PRODUCT_RESYNC_STATE_OPTION, array() );
                if ( ! is_array( $state ) ) {
                        $state = array();
                }
                $status = isset( $state['status'] ) ? $state['status'] : '';
                if ( in_array( $status, array( 'running', 'retrying' ), true ) ) {
                        $this->schedule_product_resync( 10 );
                        return true;
                }
                $requested_at = isset( $state['requested_at'] ) ? absint( $state['requested_at'] ) : 0;
                if ( $requested_at && ( time() - $requested_at ) < self::PRODUCT_RESYNC_MIN_INTERVAL ) {
                        return false;
                }
                update_option(
                        self::PRODUCT_RESYNC_STATE_OPTION,
                        array(
                                'status'       => 'running',
                                'offset'       => 0,
                                'sent'         => 0,
                                'attempts'     => 0,
                                'announced'    => 0,
                                'requested_at' => time(),
                                'source'       => sanitize_key( $source ),
                                'last_error'   => '',
                        ),
                        false
                );
                $this->core()->debug_log( 'product_resync REQUESTED', array( 'source' => $source ) );
                $this->schedule_product_resync( 10 );
                return true;
        }

        /**
         * Send one page (50 products) of a requested resend and schedule the next.
         * Runs on WP-Cron so it needs no open admin page and resumes where it stopped.
         */
        public function run_product_resync() {
                $state = get_option( self::PRODUCT_RESYNC_STATE_OPTION, array() );
                if ( ! is_array( $state ) || ! in_array( isset( $state['status'] ) ? $state['status'] : '', array( 'running', 'retrying' ), true ) ) {
                        return;
                }
                if ( ! $this->core()->is_configured() || ! $this->core()->has_wc() || ! $this->core()->sync_products_enabled() ) {
                        return;
                }
                if ( ! $this->acquire_lock( self::PRODUCT_RESYNC_LOCK_OPTION, 180 ) ) {
                        $this->schedule_product_resync( 60 );
                        return;
                }
                if ( function_exists( 'wp_raise_memory_limit' ) ) {
                        wp_raise_memory_limit( 'admin' );
                }

                $offset = isset( $state['offset'] ) ? absint( $state['offset'] ) : 0;
                $error  = '';
                $done   = false;
                // Vigent stops asking once it hears the resend has really begun.
                if ( empty( $state['announced'] ) ) {
                        $ack = $this->core()->send_event(
                                'sync.resync.started',
                                array( 'site_url' => home_url(), 'kinds' => array( 'products' ) ),
                                false
                        );
                        if ( empty( $ack['success'] ) ) {
                                $error = isset( $ack['body'] ) ? wp_strip_all_tags( (string) $ack['body'] ) : __( 'خطای نامشخص', 'vigent-woo' );
                        } else {
                                $state['announced'] = 1;
                        }
                }
                if ( '' === $error ) {
                        $result = $this->sync_batch( 'products', $offset, self::MAX_BATCH_SIZE );
                        if ( ! empty( $result['errors'] ) ) {
                                $error = (string) $result['errors'][0];
                        } else {
                                $state['sent'] = ( isset( $state['sent'] ) ? absint( $state['sent'] ) : 0 ) + absint( $result['sent'] );
                                $done          = ! empty( $result['done'] );
                                $offset       += self::MAX_BATCH_SIZE;
                        }
                }

                if ( '' !== $error ) {
                        $attempts            = ( isset( $state['attempts'] ) ? absint( $state['attempts'] ) : 0 ) + 1;
                        $state['attempts']   = $attempts;
                        $state['status']     = $attempts >= self::PRODUCT_RESYNC_MAX_ATTEMPTS ? 'failed' : 'retrying';
                        $state['last_error'] = substr( $error, 0, 500 );
                } else {
                        $state['attempts']   = 0;
                        $state['status']     = $done ? 'complete' : 'running';
                        $state['offset']     = $offset;
                        $state['last_error'] = '';
                        if ( $done ) {
                                $state['finished_at'] = current_time( 'mysql' );
                        }
                }
                $state['last_attempt'] = current_time( 'mysql' );
                update_option( self::PRODUCT_RESYNC_STATE_OPTION, $state, false );
                $this->release_lock( self::PRODUCT_RESYNC_LOCK_OPTION );

                $this->core()->debug_log( 'product_resync PAGE', array(
                        'status' => $state['status'],
                        'offset' => $state['offset'],
                        'sent'   => isset( $state['sent'] ) ? $state['sent'] : 0,
                        'error'  => $error,
                ) );
                if ( 'retrying' === $state['status'] ) {
                        $this->schedule_product_resync( 300 );
                } elseif ( 'running' === $state['status'] ) {
                        $this->schedule_product_resync( 20 );
                }
        }

        /** Schedule the next resend page without creating duplicate cron events. */
        private function schedule_product_resync( $delay ) {
                if ( ! wp_next_scheduled( 'vigent_woo_product_resync' ) ) {
                        wp_schedule_single_event( time() + max( 10, absint( $delay ) ), 'vigent_woo_product_resync' );
                }
        }

        public function on_order_status_changed( $order_id, $old_status, $new_status, $order = null ) {
                $this->queue_order( $order_id, 'order.updated' );

                // Whenever an order transitions into or out of a "successful"
                // (paid) status, two things need to happen:
                //   1. Invalidate the cached list of customer IDs with paid
                //      orders, so the next bulk-sync sees the up-to-date set.
                //   2. If the order is now paid AND the customer exists as a WP
                //      user, queue the customer too — this is how a brand-new
                //      customer who just paid for their first order gets synced
                //      to Vigent (their user_register hook fired before they
                //      had any paid orders, so queue_customer skipped them).
                if ( ! $this->core()->sync_customers_enabled() ) {
                        return;
                }
                $paid_statuses = self::SUCCESSFUL_ORDER_STATUSES;
                $was_paid = in_array( $old_status, $paid_statuses, true );
                $is_paid  = in_array( $new_status, $paid_statuses, true );
                if ( $was_paid === $is_paid ) {
                        // No transition in/out of paid — nothing extra to do.
                        return;
                }
                // Cache invalidation: the set of "customers with paid orders"
                // just changed.
                $this->invalidate_customers_with_orders_cache();
                // Only queue the customer when transitioning INTO a paid status.
                // (Transitioning OUT — e.g. a completed order is refunded —
                // doesn't un-sync the customer from Vigent; we leave them there
                // for historical support context.)
                if ( ! $is_paid ) {
                        return;
                }
                if ( ! $order ) {
                        $order = wc_get_order( $order_id );
                }
                if ( ! $order ) {
                        return;
                }
                $customer_id = (int) $order->get_customer_id();
                if ( $customer_id > 0 ) {
                        $this->queue_customer( $customer_id, 'customer.updated' );
                }
        }

        private function queue_order( $order_id, $topic ) {
                $order_id = absint( $order_id );
                if ( ! $order_id || ! $this->core()->sync_orders_enabled() ) {
                        return;
                }
                // Cancelled-order handling: when an order is in (or transitions
                // to) a status in EXCLUDED_ORDER_STATUSES (currently = cancelled),
                // we send an `order.deleted` event instead of `order.updated`.
                // Vigent will then physically delete the row from its DB on
                // the next delta flush (~5 minutes), so the agent's order list
                // doesn't get polluted with dead rows.
                //
                // Why delete instead of update-with-status=cancelled?
                //   • Lighter on the panel DB (no row at all vs. a stale row).
                //   • The "delete cancelled" bulk button on the orders page
                //     is one click away if the shop owner wants to clean up
                //     historical cancelled orders that were synced before
                //     this v4.3.3 logic existed.
                //   • If a customer asks "what happened to my cancelled order?",
                //     the agent can still look it up in WooCommerce via the
                //     orders API (the agent has the order number from the chat
                //     transcript); it just won't show up in the Vigent order
                //     list anymore.
                //
                // We compute $is_excluded here ONCE and use it to pick the
                // right topic. The bulk-sync (sync_batch) still skips
                // excluded orders entirely (no point in deleting something
                // that was never created), but the delta queue sends a delete
                // so that previously-synced orders get cleaned up.
                $is_excluded = false;
                if ( function_exists( 'wc_get_order' ) ) {
                        $order = wc_get_order( $order_id );
                        if ( $order && $this->is_order_excluded( $order->get_status() ) ) {
                                $is_excluded = true;
                        }
                }
                if ( $is_excluded ) {
                        // Send a delete event so Vigent removes the row on the
                        // next flush. We pass the order's id in the data payload
                        // (the server's deleteOrderFromWoo needs it to find the
                        // row by externalOrderId). We use a minimal payload —
                        // no billing, no line items — to keep the delta small.
                        $delete_data = array( 'id' => $order_id );
                        $this->enqueue_delta( 'order', $order_id, 'order.deleted', $delete_data );
                        return;
                }
                $this->enqueue_delta( 'order', $order_id, $topic );
        }

        /**
         * Check if an order status is in the EXCLUDED_ORDER_STATUSES list.
         *
         * WooCommerce is inconsistent about status naming:
         *   • wc_get_order_statuses() returns keys WITH the "wc-" prefix
         *     (e.g. "wc-cancelled", "wc-completed").
         *   • WC_Order::get_status() returns the status WITHOUT the prefix
         *     (e.g. "cancelled", "completed").
         *   • wc_get_orders() accepts both forms in the `status` parameter.
         *
         * EXCLUDED_ORDER_STATUSES uses the "wc-" form (to match
         * wc_get_order_statuses() keys for the array_diff in count_items).
         * But get_status() returns the no-prefix form, so a naive
         * in_array( get_status(), EXCLUDED_ORDER_STATUSES ) would FAIL.
         *
         * This helper normalizes the input by accepting either form and
         * checking both. We use it in queue_order and sync_batch to keep
         * the comparison logic in one place.
         *
         * @param string $status Order status (with or without "wc-" prefix).
         * @return bool True if the status is in the excluded list.
         */
        private function is_order_excluded( $status ) {
                if ( empty( $status ) || ! is_string( $status ) ) {
                        return false;
                }
                // Normalize: ensure "wc-" prefix.
                $normalized = ( strpos( $status, 'wc-' ) === 0 ) ? $status : 'wc-' . $status;
                return in_array( $normalized, self::EXCLUDED_ORDER_STATUSES, true );
        }

        /**
         * Customer change handler.
         *
         * Multiple WP/WC hooks can fire for the same customer during a single
         * save operation (e.g. on the my-account page, WC fires
         * woocommerce_save_account_details AND profile_update). The delta
         * queue coalesces them into one event keyed by entity:entity_id, so
         * we don't send the customer twice.
         *
         * We also filter out non-customer users early. Admins, editors, and
         * shop managers don't need to be synced to Vigent — they're not
         * customers.
         *
         * @param int|\WP_User $user User ID or WP_User object.
         * @return void
         */
        public function on_customer_change( $user ) {
                $user_id = is_object( $user ) && isset( $user->ID ) ? (int) $user->ID : (int) $user;
                if ( ! $user_id ) {
                        return;
                }
                // Only sync if customers sync is enabled. We check here (not in
                // queue_customer) because queue_customer is private and we want
                // to bail as early as possible — before get_userdata() is even
                // called, which has a small but non-zero cost on every page load.
                if ( ! $this->core()->sync_customers_enabled() ) {
                        return;
                }
                $this->queue_customer( $user_id, 'customer.updated' );
        }

        private function queue_customer( $user_id, $topic ) {
                $user_id = absint( $user_id );
                if ( ! $user_id ) {
                        return;
                }
                // Skip non-customer users. WP administrators, editors, and shop
                // managers should never be exposed as «customers» in Vigent —
                // their contact info would leak internal staff data.
                if ( ! function_exists( 'get_userdata' ) ) {
                        return;
                }
                $user = get_userdata( $user_id );
                if ( ! $user ) {
                        return;
                }
                // A user is a «customer» if:
                //   • they have the 'customer' role (the WooCommerce default), OR
                //   • they have billing_email / billing_phone set (covers users
                //     who never had the role assigned explicitly but placed an
                //     order as a guest-converted-to-customer).
                $is_customer_role = is_array( $user->roles ) && in_array( 'customer', $user->roles, true );
                $has_billing      = ! empty( get_user_meta( $user_id, 'billing_phone', true ) )
                        || ! empty( get_user_meta( $user_id, 'billing_email', true ) );
                if ( ! $is_customer_role && ! $has_billing ) {
                        return;
                }
                // Stricter filter: only sync customers who have at least one
                // PAID order (status = completed or processing). A registered
                // user with no successful purchase is just a prospect — not a
                // customer worth loading into Vigent's CRM. They will be queued
                // automatically the moment their first order is paid, via the
                // on_order_status_changed hook below.
                if ( ! $this->customer_has_successful_orders( $user_id ) ) {
                        return;
                }
                $this->enqueue_delta( 'customer', $user_id, $topic );
        }

        /**
         * Add or coalesce an entity change. Hooks only write locally; the cron flush
         * sends at most one request for the latest state of each changed entity.
         */
        public function enqueue_delta( $entity, $entity_id, $topic, $data = null ) {
                if ( ! in_array( $entity, array( 'product', 'order', 'customer' ), true ) ) {
                        return false;
                }
                if ( 'product' === $entity && ! $this->core()->sync_products_enabled() ) {
                        return false;
                }
                if ( 'order' === $entity && ! $this->core()->sync_orders_enabled() ) {
                        return false;
                }
                if ( 'customer' === $entity && ! $this->core()->sync_customers_enabled() ) {
                        return false;
                }
                $entity_id = absint( $entity_id );
                if ( ! $entity_id ) {
                        return false;
                }

                if ( ! $this->acquire_lock( self::QUEUE_LOCK_OPTION, 5 ) ) {
                        wp_schedule_single_event( time() + 5, 'vigent_woo_enqueue_delta_retry', array( $entity, $entity_id, $topic, $data ) );
                        return false;
                }
                $queue = $this->get_delta_queue();
                $key   = $entity . ':' . $entity_id;
                $old   = isset( $queue[ $key ] ) && is_array( $queue[ $key ] ) ? $queue[ $key ] : array();

                // A create followed by edits is still a create. A delete always wins;
                // recreating a deleted entity becomes a fresh create.
                if ( ! empty( $old['topic'] ) ) {
                        if ( false !== strpos( $old['topic'], '.created' ) && false !== strpos( $topic, '.updated' ) ) {
                                $topic = $old['topic'];
                        } elseif ( false !== strpos( $old['topic'], '.deleted' ) && false === strpos( $topic, '.created' ) ) {
                                // A late update hook can fire during trash/delete. Keep the tombstone;
                                // only an explicit create is allowed to resurrect the entity.
                                $topic = $old['topic'];
                                $data  = isset( $old['data'] ) && is_array( $old['data'] ) ? $old['data'] : $data;
                        }
                }

                $queue[ $key ] = array(
                        'event_id'  => wp_generate_uuid4(),
                        'entity'    => $entity,
                        'entity_id' => $entity_id,
                        'topic'     => sanitize_text_field( $topic ),
                        'data'      => is_array( $data ) ? $data : null,
                        'changed_at'=> gmdate( 'c' ),
                        'attempts'  => isset( $old['attempts'] ) ? (int) $old['attempts'] : 0,
                        'last_error'=> isset( $old['last_error'] ) ? (string) $old['last_error'] : '',
                );

                while ( count( $queue ) > self::MAX_QUEUE_SIZE ) {
                        unset( $queue[ $this->oldest_droppable_key( $queue ) ] );
                }
                $this->save_delta_queue( $queue );
                $this->release_lock( self::QUEUE_LOCK_OPTION );
                return true;
        }

        /** Creates and deletes go out before updates. */
        private function is_priority_entry( $entry ) {
                $topic = is_array( $entry ) && isset( $entry['topic'] ) ? (string) $entry['topic'] : '';
                return false !== strpos( $topic, '.created' ) || false !== strpos( $topic, '.deleted' );
        }

        /** A full queue drops its oldest update before any create or delete. */
        private function oldest_droppable_key( $queue ) {
                foreach ( $queue as $key => $entry ) {
                        if ( ! $this->is_priority_entry( $entry ) ) {
                                return $key;
                        }
                }
                reset( $queue );
                return key( $queue );
        }

        /**
         * Queue keys in send order: creates and deletes first, then updates, each
         * group oldest first. A key keeps its place when it is queued again, so a new
         * product used to wait behind every product some tool had re-saved.
         */
        private function delta_send_order( $queue ) {
                $first = array();
                $rest  = array();
                foreach ( $queue as $key => $entry ) {
                        if ( $this->is_priority_entry( $entry ) ) {
                                $first[] = $key;
                        } else {
                                $rest[] = $key;
                        }
                }
                return array_merge( $first, $rest );
        }

        public function get_delta_queue() {
                $queue = get_option( self::DELTA_QUEUE_OPTION, array() );
                return is_array( $queue ) ? $queue : array();
        }

        private function save_delta_queue( $queue ) {
                if ( false === get_option( self::DELTA_QUEUE_OPTION, false ) ) {
                        add_option( self::DELTA_QUEUE_OPTION, $queue, '', 'no' );
                        return;
                }
                update_option( self::DELTA_QUEUE_OPTION, $queue, false );
        }

        public function get_delta_status() {
                $state = get_option( self::SYNC_STATE_OPTION, array() );
                if ( ! is_array( $state ) ) {
                        $state = array();
                }
                return array_merge(
                        array(
                                'queue_count'        => count( $this->get_delta_queue() ),
                                'last_attempt'       => null,
                                'last_success'       => null,
                                'last_error'         => '',
                                'dropped_total'      => 0,
                                'last_dropped'       => null,
                                'last_dropped_error' => '',
                        ),
                        $state
                );
        }

        /**
         * WP-Cron entry point. Keeps sending batches for FLUSH_TIME_BUDGET seconds
         * and, when changes are still queued after that, asks for one more run a
         * minute later (a single event, never a duplicate).
         */
        public function run_scheduled_flush() {
                // The recurring event and the follow-up can both be due in one cron
                // request; together they stay inside one budget.
                $budget = self::FLUSH_TIME_BUDGET - $this->flush_seconds_spent;
                if ( $budget < 2 ) {
                        $this->schedule_flush_follow_up();
                        return;
                }
                if ( function_exists( 'wp_raise_memory_limit' ) ) {
                        wp_raise_memory_limit( 'admin' );
                }
                $started = microtime( true );
                $result  = $this->flush_delta_queue( self::MAX_BATCH_SIZE, $budget, 0 );
                $seconds = microtime( true ) - $started;
                $this->flush_seconds_spent += $seconds;

                if ( ! empty( $result['success'] ) && ! empty( $result['remaining'] ) && in_array( $result['stopped'], array( 'time', 'memory' ), true ) ) {
                        $this->schedule_flush_follow_up();
                }
                $this->core()->debug_log( 'delta_flush RUN', array(
                        'batches'   => $result['batches'],
                        'sent'      => $result['sent'],
                        'unchanged' => $result['unchanged'],
                        'remaining' => $result['remaining'],
                        'stopped'   => $result['stopped'],
                        'seconds'   => round( $seconds, 1 ),
                ) );
        }

        private function schedule_flush_follow_up() {
                if ( ! wp_next_scheduled( self::FLUSH_MORE_HOOK ) ) {
                        wp_schedule_single_event( time() + 60, self::FLUSH_MORE_HOOK );
                }
        }

        /**
         * Send coalesced changes in signed `sync.batch` requests of up to 50 events.
         *
         * Creates and deletes go before updates, and a product update whose payload
         * matches what Vigent last accepted leaves the queue without being sent.
         * Up to $max_batches requests are made (0 = until the queue is empty), and
         * none is started that would likely end after $time_budget seconds.
         */
        public function flush_delta_queue( $limit = self::MAX_BATCH_SIZE, $time_budget = self::FLUSH_SINGLE_BUDGET, $max_batches = 1 ) {
                $limit       = max( 1, min( self::MAX_BATCH_SIZE, absint( $limit ) ) );
                $max_batches = absint( $max_batches );
                $started     = microtime( true );
                $deadline    = $started + max( 1, (float) $time_budget );
                $summary     = array( 'batches' => 0, 'unchanged' => 0 );
                if ( ! $this->core()->is_configured() || ! $this->core()->has_wc() ) {
                        return array_merge( $summary, array( 'success' => false, 'sent' => 0, 'remaining' => count( $this->get_delta_queue() ), 'stopped' => 'error', 'message' => __( 'اتصال یا ووکامرس آماده نیست.', 'vigent-woo' ) ) );
                }
                if ( ! $this->acquire_lock( self::FLUSH_LOCK_OPTION, 120 ) ) {
                        return array_merge( $summary, array( 'success' => true, 'sent' => 0, 'remaining' => count( $this->get_delta_queue() ), 'stopped' => 'busy', 'message' => __( 'ارسال دیگری در حال انجام است.', 'vigent-woo' ) ) );
                }

                $was_empty = 0 === count( $this->get_delta_queue() );
                $sent      = 0;
                $success   = true;
                $error     = '';
                $stopped   = 'empty';
                // Entries already sent or dropped in this run, by key and event_id, so
                // one that could not be removed from the queue is not sent twice.
                $handled   = array();
                while ( true ) {
                        $round_started = microtime( true );
                        $batch         = $this->collect_delta_batch( $limit, $deadline, $handled );
                        $summary['unchanged'] += $batch['unchanged'];
                        if ( empty( $batch['events'] ) ) {
                                if ( $batch['stopped'] ) {
                                        $stopped = $batch['stopped'];
                                }
                                break;
                        }
                        $result = $this->send_delta_batch( $batch['events'], $batch['entries'], $batch['hashes'] );
                        $summary['batches']++;
                        if ( empty( $result['success'] ) ) {
                                $success = false;
                                $error   = $result['error'];
                                $stopped = 'error';
                                break;
                        }
                        $sent += count( $batch['events'] );
                        if ( $batch['stopped'] ) {
                                $stopped = $batch['stopped'];
                                break;
                        }
                        if ( $max_batches && $summary['batches'] >= $max_batches ) {
                                $stopped = 'limit';
                                break;
                        }
                        // Do not start a batch that would likely finish past the budget.
                        $now = microtime( true );
                        if ( $now + ( $now - $round_started ) > $deadline ) {
                                $stopped = 'time';
                                break;
                        }
                        if ( $this->memory_nearly_full() ) {
                                $stopped = 'memory';
                                break;
                        }
                }
                $this->release_lock( self::FLUSH_LOCK_OPTION );

                if ( ! $success ) {
                        $message = $error;
                } elseif ( $sent > 0 ) {
                        $message = __( 'تغییرات با موفقیت ارسال شد.', 'vigent-woo' );
                } elseif ( $was_empty ) {
                        $message = __( 'تغییری برای ارسال نیست.', 'vigent-woo' );
                } else {
                        $message = __( 'مورد معتبری برای ارسال نبود.', 'vigent-woo' );
                }
                return array_merge(
                        $summary,
                        array(
                                'success'   => $success,
                                'sent'      => $sent,
                                'remaining' => count( $this->get_delta_queue() ),
                                'stopped'   => $stopped,
                                'message'   => $message,
                        )
                );
        }

        /**
         * Build the next batch: walk the queue in send order, materialize entries
         * until $limit events are ready, and drop the ones with nothing to send.
         *
         * @return array{events:array, entries:array, hashes:array, unchanged:int, stopped:string}
         *         `stopped` is 'time' or 'memory' when the walk ended early, else ''.
         */
        private function collect_delta_batch( $limit, $deadline, &$handled ) {
                $queue     = $this->get_delta_queue();
                $events    = array();
                $hashes    = array();
                $stale     = array();
                $unchanged = 0;
                $stopped   = '';
                foreach ( $this->delta_send_order( $queue ) as $key ) {
                        if ( count( $events ) >= $limit ) {
                                break;
                        }
                        if ( microtime( true ) >= $deadline ) {
                                $stopped = 'time';
                                break;
                        }
                        if ( $this->memory_nearly_full() ) {
                                $stopped = 'memory';
                                break;
                        }
                        $entry  = $queue[ $key ];
                        $run_id = $key . '|' . ( isset( $entry['event_id'] ) ? (string) $entry['event_id'] : '' );
                        if ( isset( $handled[ $run_id ] ) ) {
                                continue;
                        }
                        $event = $this->materialize_delta( $entry );
                        if ( ! $event ) {
                                // Nothing left to send (sync switched off, order deleted): these
                                // leave the queue immediately instead of riding along with a batch.
                                $stale[ $key ]      = $entry;
                                $handled[ $run_id ] = true;
                                continue;
                        }
                        $hash = '';
                        if ( 0 === strpos( (string) $key, 'product:' ) && 'product.deleted' !== $event['topic'] ) {
                                $hash = $this->product_payload_hash( $event['data'] );
                                if ( 'product.updated' === $event['topic'] && $this->product_matches_last_sync( absint( substr( (string) $key, 8 ) ), $hash ) ) {
                                        $stale[ $key ]      = $entry;
                                        $handled[ $run_id ] = true;
                                        $unchanged++;
                                        continue;
                                }
                        }
                        $events[ $key ] = $event;
                        $hashes[ $key ] = $hash;
                }
                if ( ! empty( $stale ) ) {
                        $this->remove_unchanged_entries( $stale );
                }

                // Send only as much as fits the server body limit; the rest keeps its place
                // in the queue and goes out with the next batch.
                $chunks  = $this->chunk_events_by_budget( $events );
                $events  = empty( $chunks ) ? array() : $chunks[0];
                $entries = array_intersect_key( $queue, $events );
                foreach ( $entries as $key => $entry ) {
                        $handled[ $key . '|' . ( isset( $entry['event_id'] ) ? (string) $entry['event_id'] : '' ) ] = true;
                }
                return array(
                        'events'    => $events,
                        'entries'   => $entries,
                        'hashes'    => array_intersect_key( $hashes, $events ),
                        'unchanged' => $unchanged,
                        'stopped'   => $stopped,
                );
        }

        /** Send one batch and settle its entries: removed on success, counted against on failure. */
        private function send_delta_batch( $events, $entries, $hashes ) {
                $result   = $this->core()->send_batch_events( array_values( $events ), false );
                $previous = get_option( self::SYNC_STATE_OPTION, array() );
                if ( ! is_array( $previous ) ) {
                        $previous = array();
                }
                $state = array(
                        'last_attempt' => current_time( 'mysql' ),
                        'last_success' => null,
                        'last_error'   => '',
                        // Dead-letter counters survive both outcomes so the settings screen can
                        // keep warning until a full push clears the backlog.
                        'dropped_total'      => isset( $previous['dropped_total'] ) ? (int) $previous['dropped_total'] : 0,
                        'last_dropped'       => isset( $previous['last_dropped'] ) ? $previous['last_dropped'] : null,
                        'last_dropped_error' => isset( $previous['last_dropped_error'] ) ? (string) $previous['last_dropped_error'] : '',
                );

                if ( ! empty( $result['success'] ) ) {
                        $this->remove_unchanged_entries( $entries );
                        $this->remember_product_hashes( $events, $hashes );
                        $state['last_success'] = current_time( 'mysql' );
                        if ( ! empty( $previous['last_success'] ) ) {
                                $state['previous_success'] = $previous['last_success'];
                        }
                } else {
                        $state['last_error'] = isset( $result['body'] ) ? wp_strip_all_tags( (string) $result['body'] ) : __( 'خطای نامشخص', 'vigent-woo' );
                        $dropped             = $this->mark_failed_entries( $entries, $state['last_error'] );
                        if ( $dropped > 0 ) {
                                $state['dropped_total']     += $dropped;
                                $state['last_dropped']       = current_time( 'mysql' );
                                $state['last_dropped_error'] = substr( $state['last_error'], 0, 500 );
                        }
                        if ( ! empty( $previous['last_success'] ) ) {
                                $state['last_success'] = $previous['last_success'];
                        }
                }

                update_option( self::SYNC_STATE_OPTION, $state, false );
                return array(
                        'success' => ! empty( $result['success'] ),
                        'error'   => $state['last_error'],
                );
        }

        /** Stop a long flush before WooCommerce objects exhaust PHP's memory. */
        private function memory_nearly_full() {
                $limit = function_exists( 'wp_convert_hr_to_bytes' ) ? wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) ) : 0;
                return $limit > 0 && memory_get_usage( true ) > $limit * 0.8;
        }

        private function materialize_delta( $entry ) {
                $topic     = isset( $entry['topic'] ) ? (string) $entry['topic'] : '';
                $entity    = isset( $entry['entity'] ) ? (string) $entry['entity'] : '';
                $entity_id = isset( $entry['entity_id'] ) ? absint( $entry['entity_id'] ) : 0;
                $data      = isset( $entry['data'] ) && is_array( $entry['data'] ) ? $entry['data'] : null;
                if ( 'product' === $entity && ! $this->core()->sync_products_enabled() ) {
                        return false;
                }
                if ( 'order' === $entity && ! $this->core()->sync_orders_enabled() ) {
                        return false;
                }
                if ( 'customer' === $entity && ! $this->core()->sync_customers_enabled() ) {
                        return false;
                }

                if ( false === strpos( $topic, '.deleted' ) ) {
                        if ( 'product' === $entity ) {
                                $product = wc_get_product( $entity_id );
                                if ( $product ) {
                                        $data = $this->core()->product_to_payload( $product );
                                } else {
                                        $topic = 'product.deleted';
                                        $data  = array( 'id' => $entity_id );
                                }
                        } elseif ( 'order' === $entity ) {
                                $order = wc_get_order( $entity_id );
                                if ( ! $order ) {
                                        return false;
                                }
                                $data = $this->core()->order_to_payload( $order );
                        } elseif ( 'customer' === $entity ) {
                                // Customer deleted? We don't have a delete hook wired up
                                // (WordPress doesn't fire one cleanly for users), so a
                                // customer_delta whose user has vanished is treated as
                                // a no-op — we skip sending rather than emit a delete
                                // event. The Vigent panel will keep its Contact record
                                // around; this is acceptable for now.
                                $payload = $this->core()->customer_to_payload( $entity_id );
                                if ( empty( $payload ) ) {
                                        return false;
                                }
                                // Skip customers with neither email nor phone — they
                                // are useless to Vigent and would create empty
                                // Contact rows that the agent can't message.
                                if ( empty( $payload['email'] ) && empty( $payload['phone'] ) ) {
                                        return false;
                                }
                                $data = $payload;
                        }
                }

                if ( ! is_array( $data ) ) {
                        $data = array( 'id' => $entity_id );
                }
                return array(
                        'event_id'  => isset( $entry['event_id'] ) ? $entry['event_id'] : wp_generate_uuid4(),
                        'topic'     => $topic,
                        'data'      => $data,
                        'changed_at'=> isset( $entry['changed_at'] ) ? $entry['changed_at'] : gmdate( 'c' ),
                );
        }

        private function remove_unchanged_entries( $sent_entries ) {
                if ( ! $this->acquire_lock( self::QUEUE_LOCK_OPTION, 5 ) ) {
                        return false;
                }
                $queue = $this->get_delta_queue();
                foreach ( $sent_entries as $key => $sent ) {
                        if ( isset( $queue[ $key ]['event_id'], $sent['event_id'] ) && hash_equals( (string) $queue[ $key ]['event_id'], (string) $sent['event_id'] ) ) {
                                unset( $queue[ $key ] );
                        }
                }
                $this->save_delta_queue( $queue );
                $this->release_lock( self::QUEUE_LOCK_OPTION );
                return true;
        }

        /**
         * Count a failed attempt against each entry and dead-letter the ones that can
         * never succeed, so one poisoned change cannot block the whole queue.
         *
         * @return int Number of entries removed from the queue.
         */
        private function mark_failed_entries( $failed_entries, $error ) {
                if ( ! $this->acquire_lock( self::QUEUE_LOCK_OPTION, 5 ) ) {
                        return 0;
                }
                $queue   = $this->get_delta_queue();
                $dropped = 0;
                foreach ( $failed_entries as $key => $failed ) {
                        if ( ! isset( $queue[ $key ]['event_id'], $failed['event_id'] ) ) {
                                continue;
                        }
                        if ( ! hash_equals( (string) $queue[ $key ]['event_id'], (string) $failed['event_id'] ) ) {
                                continue;
                        }
                        $attempts = isset( $queue[ $key ]['attempts'] ) ? (int) $queue[ $key ]['attempts'] + 1 : 1;
                        if ( $attempts >= self::MAX_DELTA_ATTEMPTS ) {
                                unset( $queue[ $key ] );
                                $dropped++;
                                continue;
                        }
                        $queue[ $key ]['attempts']   = $attempts;
                        $queue[ $key ]['last_error'] = substr( (string) $error, 0, 500 );
                }
                $this->save_delta_queue( $queue );
                $this->release_lock( self::QUEUE_LOCK_OPTION );
                return $dropped;
        }

        /**
         * Split events into request-sized groups, preserving keys.
         *
         * A single event bigger than the budget is still returned on its own — the
         * server decides, and repeated rejections dead-letter it rather than stalling
         * every other change behind it.
         */
        private function chunk_events_by_budget( $events ) {
                $chunks  = array();
                $current = array();
                $bytes   = 0;
                foreach ( $events as $key => $event ) {
                        $encoded = wp_json_encode( $event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
                        $size    = false === $encoded ? 0 : strlen( $encoded );
                        if ( ! empty( $current ) && ( $bytes + $size ) > self::MAX_BATCH_BYTES ) {
                                $chunks[] = $current;
                                $current  = array();
                                $bytes    = 0;
                        }
                        $current[ $key ] = $event;
                        $bytes          += $size;
                }
                if ( ! empty( $current ) ) {
                        $chunks[] = $current;
                }
                return $chunks;
        }

        private function acquire_lock( $option, $ttl ) {
                $now = time();
                for ( $attempt = 0; $attempt < 5; $attempt++ ) {
                        if ( add_option( $option, $now, '', 'no' ) ) {
                                return true;
                        }
                        $created = (int) get_option( $option, 0 );
                        if ( ! $created || ( $now - $created ) > $ttl ) {
                                delete_option( $option );
                                continue;
                        }
                        usleep( 20000 );
                }
                return false;
        }

        private function release_lock( $option ) {
                delete_option( $option );
        }

        /**
         * Get the list of WordPress user IDs that have at least one paid
         * (completed or processing) shop_order.
         *
         * Used by both count_items('customers') and sync_batch('customers')
         * so that the bulk-sync wizard ONLY sends customers who have actually
         * purchased something — not every registered user with the 'customer'
         * role (which includes abandoned checkouts, never-paid signups, etc.).
         *
         * The result is cached in a transient for 10 minutes to avoid
         * re-running the orders query on every wizard page (the wizard paginates
         * 50 customers at a time, so a 1000-customer store would otherwise hit
         * this 20 times). The cache is invalidated by on_order_status_changed
         * whenever an order transitions into or out of a paid status.
         *
         * Returns the IDs sorted DESC (newest user_id first) so the wizard
         * syncs the most recent customers first — same UX as before.
         *
         * @return int[] Array of WP user IDs (may be empty).
         */
        public function get_customer_ids_with_successful_orders() {
                if ( ! $this->core()->has_wc() || ! function_exists( 'wc_get_orders' ) ) {
                        return array();
                }
                $cached = get_transient( self::CUSTOMERS_WITH_ORDERS_CACHE_KEY );
                if ( is_array( $cached ) ) {
                        return $cached;
                }
                // Fetch all paid order IDs. wc_get_orders abstracts HPOS vs
                // legacy post storage, so this works on both. We ask for IDs
                // only (no full object hydration) to keep memory low on stores
                // with thousands of historical orders.
                $order_ids = wc_get_orders( array(
                        'status'  => self::SUCCESSFUL_ORDER_STATUSES,
                        'type'    => 'shop_order',
                        'limit'   => -1,
                        'return'  => 'ids',
                        'orderby' => 'date',
                        'order'   => 'DESC',
                ) );
                if ( empty( $order_ids ) ) {
                        set_transient( self::CUSTOMERS_WITH_ORDERS_CACHE_KEY, array(), self::CUSTOMERS_WITH_ORDERS_CACHE_TTL );
                        return array();
                }
                // De-duplicate by customer_id. We iterate the order IDs and
                // pull each order's customer_id. For very large stores this is
                // O(N) order fetches, but wc_get_order() is internally cached
                // by WooCommerce so subsequent calls in the same request are
                // cheap. The result is also cached in a transient so the next
                // wizard page skips this entirely.
                $seen = array();
                foreach ( $order_ids as $order_id ) {
                        $order = wc_get_order( $order_id );
                        if ( ! $order ) {
                                continue;
                        }
                        $cid = (int) $order->get_customer_id();
                        if ( $cid > 0 ) {
                                $seen[ $cid ] = true;
                        }
                }
                $ids = array_keys( $seen );
                // Sort DESC so newest customers come first in the sync wizard.
                rsort( $ids );
                set_transient( self::CUSTOMERS_WITH_ORDERS_CACHE_KEY, $ids, self::CUSTOMERS_WITH_ORDERS_CACHE_TTL );
                return $ids;
        }

        /**
         * Check if a single user has at least one paid order.
         *
         * Used by queue_customer() on every customer-change hook to decide
         * whether the change is worth syncing. We query with limit=1 so it's
         * fast even on stores with thousands of orders per customer.
         *
         * @param int $user_id WordPress user ID.
         * @return bool True if the user has ≥1 completed/processing order.
         */
        private function customer_has_successful_orders( $user_id ) {
                $user_id = absint( $user_id );
                if ( ! $user_id || ! $this->core()->has_wc() || ! function_exists( 'wc_get_orders' ) ) {
                        return false;
                }
                $orders = wc_get_orders( array(
                        'customer_id' => $user_id,
                        'status'      => self::SUCCESSFUL_ORDER_STATUSES,
                        'type'        => 'shop_order',
                        'limit'       => 1,
                        'return'      => 'ids',
                ) );
                return ! empty( $orders );
        }

        /**
         * Invalidate the cached list of customer IDs with paid orders.
         *
         * Called from on_order_status_changed whenever an order transitions
         * into or out of a "successful" status, so the next bulk-sync page
         * sees the up-to-date list.
         */
        public function invalidate_customers_with_orders_cache() {
                delete_transient( self::CUSTOMERS_WITH_ORDERS_CACHE_KEY );
        }

        /**
         * Get the set of WP user IDs that have already been synced to Vigent
         * during a previous bulk-sync run.
         *
         * Stored as a PHP array in the WP option `vigent_woo_synced_customer_ids`.
         * The set grows on every successful sync_batch('customers') call —
         * we add the page of IDs that was just sent. It is NEVER shrunk
         * automatically (a customer that was synced stays "synced" even if
         * their order is later refunded — we want the agent to keep their
         * history).
         *
         * This is what powers the "X از N قبلاً ارسال شده" hint on the
         * management card: we compare the set of paying-customer IDs against
         * this stored set to figure out how many are NEW (will be added to
         * Vigent) vs already known (will just be updated).
         *
         * @return int[] Associative array [user_id => true] for O(1) lookup.
         */
        public function get_synced_customer_ids() {
                $ids = get_option( 'vigent_woo_synced_customer_ids', array() );
                if ( ! is_array( $ids ) ) {
                        $ids = array();
                }
                return $ids;
        }

        /**
         * Mark a list of WP user IDs as "synced to Vigent".
         *
         * Called from sync_batch('customers') after a successful page send.
         * We merge the new IDs into the stored set so subsequent runs can
         * compute the "new vs. already-known" delta.
         *
         * @param int[] $user_ids IDs to mark as synced.
         */
        public function mark_customers_synced( $user_ids ) {
                if ( empty( $user_ids ) ) {
                        return;
                }
                $existing = $this->get_synced_customer_ids();
                $changed = false;
                foreach ( $user_ids as $uid ) {
                        $uid = (int) $uid;
                        if ( $uid > 0 && ! isset( $existing[ $uid ] ) ) {
                                $existing[ $uid ] = true;
                                $changed = true;
                        }
                }
                if ( $changed ) {
                        update_option( 'vigent_woo_synced_customer_ids', $existing, false );
                }
        }

        /**
         * Compute stats about paying customers and their sync state.
         *
         * Returns:
         *   • total       — total number of customers with ≥1 paid order
         *                   (the same number the wizard / sync_batch will send).
         *   • synced      — how many of those have already been sent to Vigent
         *                   in a previous successful bulk-sync run.
         *   • new         — how many are NEW (will be added to Vigent as new
         *                   contacts on the next sync). Computed as total - synced.
         *
         * Used by the management card to show:
         *   "N مشتری با خرید موفق — X تا قبلاً ارسال شده، Y تا جدید اضافه می‌شود"
         *
         * Note: this is a best-effort count. The "synced" set is tracked in the
         * WP option `vigent_woo_synced_customer_ids` and grows on every successful
         * sync_batch('customers') call. If a customer exists in Vigent but their
         * ID is not in this option (e.g. they were synced by an older plugin
         * version before this tracking was added, or via the delta queue), they
         * will be counted as "new" and re-sent — Vigent's upsert logic will
         * just update them instead of creating a duplicate (it matches by phone
         * / email / externalId), so this is safe.
         *
         * @return array{total:int, synced:int, new:int}
         */
        public function get_paying_customer_stats() {
                $all_ids = $this->get_customer_ids_with_successful_orders();
                $total   = count( $all_ids );
                if ( $total === 0 ) {
                        return array( 'total' => 0, 'synced' => 0, 'new' => 0 );
                }
                $synced_set = $this->get_synced_customer_ids();
                $synced     = 0;
                foreach ( $all_ids as $uid ) {
                        if ( isset( $synced_set[ $uid ] ) ) {
                                $synced++;
                        }
                }
                return array(
                        'total'  => $total,
                        'synced' => $synced,
                        'new'    => max( 0, $total - $synced ),
                );
        }

        /**
         * Count ALL non-excluded orders in the store, WITHOUT the MAX_ORDERS_TO_SYNC
         * cap. Used by the admin UI to show the shop owner:
         *
         *   • "شما ۳۵۲۳ سفارش قابل پیگیری دارید — فقط ۱۰۰۰ سفارش آخر ارسال می‌شود"
         *     (when total > cap)
         *   • "شما ۳۲ سفارش قابل پیگیری دارید — همه ارسال می‌شوند"
         *     (when total <= cap)
         *
         * Returns an associative array:
         *   • total    — count of all non-excluded (i.e. non-cancelled) orders.
         *   • cap      — MAX_ORDERS_TO_SYNC (1000). Constant, returned for the
         *                UI so it doesn't have to hard-code the number.
         *   • syncable — min(total, cap) — the number of orders that will
         *                actually be sent on the next sync. Same as count_items
         *                ('orders'), but without re-running the query (we
         *                already have $total).
         *   • cancelled — count of cancelled orders (informational; the UI may
         *                show "X سفارش لغو شده نادیده گرفته شد" if > 0).
         *
         * @return array{total:int, cap:int, syncable:int, cancelled:int}
         */
        public function get_order_stats() {
                $cap = self::MAX_ORDERS_TO_SYNC;
                if ( ! $this->core()->has_wc() || ! function_exists( 'wc_get_orders' ) ) {
                        return array( 'total' => 0, 'cap' => $cap, 'syncable' => 0, 'cancelled' => 0 );
                }
                // Count non-excluded orders (= orders we WILL sync). We pass the
                // list of included statuses (everything except cancelled) to
                // wc_get_orders, exactly like count_items('orders') does.
                $all_statuses = function_exists( 'wc_get_order_statuses' )
                        ? array_keys( wc_get_order_statuses() )
                        : array( 'pending', 'on-hold', 'processing', 'completed', 'refunded', 'failed', 'cancelled' );
                $included = array_values( array_diff( $all_statuses, self::EXCLUDED_ORDER_STATUSES ) );
                $args = array(
                        'status'  => $included,
                        'type'    => 'shop_order',
                        'limit'   => 1,
                        'paginate' => true,
                        'return'  => 'ids',
                );
                $result = wc_get_orders( $args );
                $total  = is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;

                // Count cancelled orders (informational). We pass status=cancelled
                // directly because that's exactly what we want to count.
                $cancelled = 0;
                $c_result = wc_get_orders( array(
                        'status'  => self::EXCLUDED_ORDER_STATUSES,
                        'type'    => 'shop_order',
                        'limit'   => 1,
                        'paginate' => true,
                        'return'  => 'ids',
                ) );
                if ( is_object( $c_result ) && isset( $c_result->total ) ) {
                        $cancelled = (int) $c_result->total;
                }

                return array(
                        'total'     => $total,
                        'cap'       => $cap,
                        'syncable'  => min( $total, $cap ),
                        'cancelled' => $cancelled,
                );
        }

        public function count_items( $kind, $filter = array() ) {
                if ( ! $this->core()->has_wc() ) {
                        return 0;
                }
                if ( 'products' === $kind && empty( $filter['category'] ) ) {
                        $counts = wp_count_posts( 'product' );
                        return isset( $counts->publish ) ? (int) $counts->publish : 0;
                }

                $args = array( 'limit' => 1, 'page' => 1, 'paginate' => true, 'return' => 'ids' );
                if ( 'products' === $kind ) {
                        $args['status'] = 'publish';
                        if ( ! empty( $filter['category'] ) ) {
                                $term = get_term( absint( $filter['category'] ), 'product_cat' );
                                if ( $term && ! is_wp_error( $term ) ) {
                                        $args['category'] = array( $term->slug );
                                }
                        }
                        $result = wc_get_products( $args );
                } elseif ( 'orders' === $kind ) {
                        // Status filter:
                        //   • If the user passed an explicit status filter (e.g. via
                        //     the management UI's status dropdown), respect it.
                        //   • Otherwise, EXCLUDE cancelled orders — the product owner
                        //     explicitly asked to skip them. Cancelled orders have
                        //     nothing to track (no shipping, no payment to chase), so
                        //     syncing them would just pollute the agent's order list.
                        //     Every OTHER status (pending, on-hold, processing,
                        //     completed, refunded, failed) is kept so the agent can
                        //     answer "where is my order?" for any active order.
                        if ( ! empty( $filter['status'] ) ) {
                                $args['status'] = array( sanitize_text_field( $filter['status'] ) );
                        } else {
                                $args['status'] = self::EXCLUDED_ORDER_STATUSES;
                                // wc_get_orders interprets `status` as "match any of
                                // these statuses" — there is no built-in "exclude"
                                // parameter. To exclude cancelled, we have to pass
                                // the full list of statuses EXCEPT cancelled.
                                // wc_get_order_statuses() returns the full
                                // slug => label map; we take every slug that's not
                                // in the excluded list.
                                if ( function_exists( 'wc_get_order_statuses' ) ) {
                                        $all_statuses = array_keys( wc_get_order_statuses() );
                                        $included     = array_values( array_diff( $all_statuses, self::EXCLUDED_ORDER_STATUSES ) );
                                        if ( ! empty( $included ) ) {
                                                $args['status'] = $included;
                                        }
                                }
                        }
                        // Only count real orders, not refunds. Without this the total
                        // includes shop_order_refund posts, which inflates the count and
                        // makes the progress bar show more pages than actually exist.
                        $args['type'] = 'shop_order';
                        $result = wc_get_orders( $args );
                        $total  = is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
                        // Cap the sync-able orders to MAX_ORDERS_TO_SYNC. The progress bar
                        // and the $done flag in sync_batch both read this count, so capping
                        // here makes the wizard stop after the most recent 1000 orders
                        // instead of grinding through the entire history.
                        if ( $total > self::MAX_ORDERS_TO_SYNC ) {
                                $total = self::MAX_ORDERS_TO_SYNC;
                        }
                        return $total;
                } elseif ( 'customers' === $kind ) {
                        // Count only customers who have at least one PAID order
                        // (status = completed or processing). This is stricter than
                        // the old "has customer role OR has billing info" check —
                        // we now skip users who registered but never actually bought
                        // anything, abandoned their cart, or had their order fail.
                        // These are the only customers worth syncing to Vigent.
                        //
                        // NOTE: Customers are NOT capped at MAX_ORDERS_TO_SYNC.
                        // The product owner asked for "no limit" — every customer
                        // with at least one paid order is synced, regardless of
                        // how many thousands there are. Orders are still capped
                        // (they're historical and the panel retains at most 2000),
                        // but customers are CRM entities and we want all of them.
                        $ids   = $this->get_customer_ids_with_successful_orders();
                        $total = count( $ids );
                        return $total;
                } else {
                        return 0;
                }
        }

        /** Send one full-sync page as a single request (maximum 50 events). */
        public function sync_batch( $kind, $offset, $batch_size = self::MAX_BATCH_SIZE, $filter = array() ) {
                $offset     = max( 0, absint( $offset ) );
                $batch_size = max( 1, min( self::MAX_BATCH_SIZE, absint( $batch_size ) ) );
                if ( ! $this->core()->has_wc() ) {
                        return array( 'sent' => 0, 'errors' => array( __( 'ووکامرس فعال نیست.', 'vigent-woo' ) ), 'total' => 0, 'done' => true );
                }

                $args = array(
                        'limit'   => $batch_size,
                        'offset'  => $offset,
                        'orderby' => 'date',
                        'order'   => 'DESC',
                        'return'  => 'objects',
                );
                $events = array();
                $items  = array();

                if ( 'products' === $kind ) {
                        $args['status'] = 'publish';
                        if ( ! empty( $filter['category'] ) ) {
                                $term = get_term( absint( $filter['category'] ), 'product_cat' );
                                if ( $term && ! is_wp_error( $term ) ) {
                                        $args['category'] = array( $term->slug );
                                }
                        }
                        $items = wc_get_products( $args );
                        foreach ( $items as $product ) {
                                $events[] = $this->make_event( 'product.updated', $this->core()->product_to_payload( $product ) );
                        }
                } elseif ( 'orders' === $kind ) {
                        // Status filter (see count_items('orders') for the full
                        // explanation): if the user passed an explicit status,
                        // respect it; otherwise EXCLUDE cancelled orders so we
                        // don't sync dead orders the customer can't ask about.
                        if ( ! empty( $filter['status'] ) ) {
                                $args['status'] = array( sanitize_text_field( $filter['status'] ) );
                        } else {
                                if ( function_exists( 'wc_get_order_statuses' ) ) {
                                        $all_statuses = array_keys( wc_get_order_statuses() );
                                        $included     = array_values( array_diff( $all_statuses, self::EXCLUDED_ORDER_STATUSES ) );
                                        if ( ! empty( $included ) ) {
                                                $args['status'] = $included;
                                        }
                                }
                        }
                        // Only fetch real orders, not refunds. wc_get_orders() can return
                        // OrderRefund objects mixed in with WC_Order, and OrderRefund does
                        // not implement get_order_number() etc. — building a payload from
                        // it crashes the whole batch. Filtering at the query level is more
                        // efficient than filtering in the foreach loop.
                        $args['type'] = 'shop_order';
                        $items = wc_get_orders( $args );
                        foreach ( $items as $order ) {
                                // Second-line defense: even with type=shop_order, some WC
                                // versions/configurations may still return non-WC_Order
                                // objects. This is_a check is cheap and prevents a crash.
                                if ( ! is_a( $order, 'WC_Order' ) ) {
                                        continue;
                                }
                                if ( 'shop_order_refund' === $order->get_type() ) {
                                        continue;
                                }
                                // Third-line defense: skip cancelled orders even if the
                                // query somehow returned them (e.g. an old WC version
                                // that ignores the status filter). Belt + suspenders.
                                if ( $this->is_order_excluded( $order->get_status() ) ) {
                                        continue;
                                }
                                $events[] = $this->make_event( 'order.updated', $this->core()->order_to_payload( $order ) );
                        }
                } elseif ( 'customers' === $kind ) {
                        // Only sync customers who have at least one PAID order
                        // (status = completed or processing). The full list is
                        // cached in a transient; we slice it by offset/batch_size
                        // to paginate the wizard. Then we use WP_User_Query with
                        // an `include` clause to hydrate the user objects for the
                        // current page only.
                        //
                        // This is stricter than the previous "all users with the
                        // customer role" filter — we now skip registered users who
                        // never actually bought anything. The Vigent panel only
                        // cares about customers who have a real purchase history.
                        $all_ids = $this->get_customer_ids_with_successful_orders();
                        $page_ids = array_slice( $all_ids, $offset, $batch_size );
                        if ( empty( $page_ids ) ) {
                                $users = array();
                        } else {
                                $user_q = new \WP_User_Query( array(
                                        'include' => $page_ids,
                                        'number'  => $batch_size,
                                        'orderby'  => 'registered',
                                        'order'    => 'DESC',
                                        'fields'   => 'all',
                                ) );
                                $users = $user_q->get_results();
                        }
                        foreach ( $users as $user ) {
                                $payload = $this->core()->customer_to_payload( $user );
                                if ( empty( $payload ) ) {
                                        continue;
                                }
                                // Skip customers with no email AND no phone — they
                                // would create empty Contact rows Vigent can't use.
                                if ( empty( $payload['email'] ) && empty( $payload['phone'] ) ) {
                                        continue;
                                }
                                $events[] = $this->make_event( 'customer.updated', $payload );
                        }
                        $items = $users;
                } else {
                        return array( 'sent' => 0, 'errors' => array( __( 'نوع همگام‌سازی نامعتبر است.', 'vigent-woo' ) ), 'total' => 0, 'done' => true );
                }

                $total = $this->count_items( $kind, $filter );
                $done  = ( $offset + count( $items ) ) >= $total || count( $items ) < $batch_size;
                // Hard cap for ORDERS only: never sync more than MAX_ORDERS_TO_SYNC
                // orders, even if count_items returned a higher number (shouldn't
                // happen since we cap there too, but this is a second-line defense).
                // Once the offset reaches the cap, we're done regardless of what the
                // DB still holds.
                //
                // CUSTOMERS are NOT capped — see the comment in count_items() above.
                if ( 'orders' === $kind && ( $offset + count( $items ) ) >= self::MAX_ORDERS_TO_SYNC ) {
                        $done = true;
                }
                if ( empty( $events ) ) {
                        return array( 'sent' => 0, 'errors' => array(), 'total' => $total, 'done' => $done );
                }

                // One page can exceed the server body limit on stores with long product
                // descriptions. Every group is sent (failures land in the retry queue), so
                // an oversized page no longer fails the whole page.
                $sent   = 0;
                $errors = array();
                $all_ok = true; // tracks whether every chunk succeeded (for marking IDs).
                foreach ( $this->chunk_events_by_budget( $events ) as $chunk ) {
                        $chunk_events = array_values( $chunk );
                        $result = $this->core()->send_batch_events( $chunk_events, true );
                        if ( ! empty( $result['success'] ) ) {
                                $sent += count( $chunk_events );
                        } else {
                                $all_ok = false;
                                // Build a detailed error message so the JS alert + debug log
                                // tell the admin exactly what failed. Without this the alert
                                // was a generic "ارسال ناموفق بود" with no actionable detail.
                                $err_body = isset( $result['body'] ) ? (string) $result['body'] : '';
                                if ( strlen( $err_body ) > 500 ) {
                                        $err_body = substr( $err_body, 0, 500 ) . '…';
                                }
                                $http_code = isset( $result['code'] ) ? (int) $result['code'] : 0;
                                /* translators: 1: HTTP code, 2: event count, 3: error body */
                                $errors[] = sprintf(
                                        __( 'HTTP %1$s | %2$s رویداد | %3$s', 'vigent-woo' ),
                                        $http_code > 0 ? (string) $http_code : '—',
                                        count( $chunk_events ),
                                        $err_body !== '' ? $err_body : __( 'پاسخی از سرور دریافت نشد.', 'vigent-woo' )
                                );
                        }
                }
                // For customers: if every chunk in this page was sent successfully,
                // mark the user IDs as "synced to Vigent". This lets the management
                // card show "X از N قبلاً ارسال شده" so the shop owner knows how
                // many customers are NEW (will be added) vs already-known (will be
                // updated). We only mark on full success — if any chunk failed we
                // don't mark, so the next retry will re-send them and the count
                // stays accurate.
                if ( 'customers' === $kind && $all_ok && $sent > 0 ) {
                        $synced_ids = array();
                        foreach ( $items as $user ) {
                                if ( is_object( $user ) && isset( $user->ID ) ) {
                                        $synced_ids[] = (int) $user->ID;
                                }
                        }
                        if ( ! empty( $synced_ids ) ) {
                                $this->mark_customers_synced( $synced_ids );
                        }
                }
                return array(
                        'sent'   => $sent,
                        'errors' => $errors,
                        'total'  => $total,
                        'done'   => $done,
                );
        }

        private function make_event( $topic, $data ) {
                return array(
                        'event_id'  => wp_generate_uuid4(),
                        'topic'     => $topic,
                        'data'      => $data,
                        'changed_at'=> gmdate( 'c' ),
                );
        }

        /** Move old per-event product/order retries into the coalesced queue. */
        public function migrate_legacy_retry_queue() {
                $legacy = $this->core()->get_retry_queue();
                $kept   = array();
                foreach ( $legacy as $item ) {
                        $topic = isset( $item['topic'] ) ? (string) $item['topic'] : '';
                        $data  = isset( $item['body'] ) ? json_decode( $item['body'], true ) : null;
                        if ( is_array( $data ) && preg_match( '/^(product|order)\\.(created|updated|deleted)$/', $topic, $match ) && ! empty( $data['id'] ) ) {
                                $this->enqueue_delta( $match[1], absint( $data['id'] ), $topic, false !== strpos( $topic, '.deleted' ) ? $data : null );
                        } else {
                                $kept[] = $item;
                        }
                }
                update_option( 'vigent_woo_retry_queue', $kept, false );
        }

        public function process_retry_queue() {
                $this->core()->process_retry_queue();
        }
}
