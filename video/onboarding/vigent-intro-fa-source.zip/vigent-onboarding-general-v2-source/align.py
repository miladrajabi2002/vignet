from difflib import SequenceMatcher
from faster_whisper import WhisperModel
from pathlib import Path
from subprocess import check_output
import json
import os
import re

import numpy as np

model_path = os.environ.get('VIGENT_WHISPER_MODEL','asr-model')
raw = Path('voice/general.pcm')
read = check_output(['ffmpeg','-v','error','-f','s16le','-ar','24000','-ac','1','-i',str(raw),'-ar','16000','-f','f32le','-'])
audio = np.frombuffer(read, dtype='<f4')
rate = 16000
duration = len(audio) / rate
transcript = raw.with_suffix('.transcript.json')

def energy(at):
    window = audio[round((at-.10)*rate):round((at+.10)*rate)]
    return np.mean(window ** 2)

def recognize():
    model = WhisperModel(model_path, device='cpu', compute_type='int8', cpu_threads=3, local_files_only=True)
    boundaries = [0.0]
    for center in np.arange(13.0,duration-4.0,13.0):
        candidates = np.arange(center-2.3,center+2.3,.04)
        boundaries.append(float(min(candidates,key=lambda x: energy(x)+abs(x-center)*1e-7)))
    boundaries.append(duration)
    words = []
    for start,end in zip(boundaries,boundaries[1:]):
        window = audio[round(start*rate):round(end*rate)]
        segments,_ = model.transcribe(window,language='fa',beam_size=5,temperature=0,condition_on_previous_text=False,
            word_timestamps=True,no_speech_threshold=.74)
        for segment in segments:
            words.extend(dict(start=round(start+w.start,3),end=round(start+w.end,3),text=w.word) for w in segment.words)
    transcript.write_text(json.dumps(words,ensure_ascii=False,indent=2)+'\n')
    return words

def normalized(string):
    table = str.maketrans('يكىؤإأآۀة','یکیواااهه')
    return re.sub(r'[^\u0621-\u063A\u0641-\u064A\u067E\u0686\u0698\u06A9\u06AF\u06CC0-9]','',string.translate(table))

heard = json.loads(transcript.read_text()) if transcript.exists() else recognize()
expected = json.loads(check_output(['node','--input-type=module','-e',
    "import {films} from './story.mjs'; console.log(JSON.stringify(films.general.lines))"],text=True))
flat = [(key,word) for key,text in expected for word in text.split()]
source_chars = [(c,index) for index,(_,word) in enumerate(flat) for c in normalized(word)]
heard_chars = [(c,index) for index,word in enumerate(heard) for c in normalized(word['text'])]
aligner = SequenceMatcher(None,''.join(c for c,_ in source_chars),''.join(c for c,_ in heard_chars),autojunk=False)
mapping = [[] for _ in flat]
for match in aligner.get_matching_blocks():
    for i in range(match.size):
        expected_word = source_chars[match.a+i][1]
        actual_word = heard_chars[match.b+i][1]
        mapping[expected_word].append(actual_word)

matched = {}
offset = .23
for index,(key,word) in enumerate(flat):
    if mapping[index]:
        start = heard[min(mapping[index])]['start'] + offset
        end = heard[max(mapping[index])]['end'] + offset
    else:
        previous = next((j for j in range(index-1,-1,-1) if mapping[j]), None)
        following = next((j for j in range(index+1,len(flat)) if mapping[j]), None)
        left = heard[max(mapping[previous])]['end'] + offset if previous is not None else offset
        right = heard[min(mapping[following])]['start'] + offset if following is not None else duration+offset
        fraction = (index-(previous if previous is not None else -1))/((following if following is not None else len(flat))-(previous if previous is not None else -1))
        start = left+max(0,right-left)*fraction
        end = min(max(start,right),start+.2)
    matched.setdefault(key,[]).append(dict(start=round(start,3),end=round(end,3),text=word,found=bool(mapping[index])))

for key,words in matched.items():
    print(f"{key:10s} {words[0]['start']:6.2f} - {words[-1]['end']:6.2f}  "+' '.join(
        w['text'] if w['found'] else '['+w['text']+']' for w in words))
print(f"{aligner.ratio():.1%} character correspondence, {duration:.2f} seconds")

Path('alignment.json').write_text(json.dumps(dict(lines=matched,seconds=duration,voiceStart=offset,ratio=aligner.ratio()),ensure_ascii=False,indent=2)+'\n')
