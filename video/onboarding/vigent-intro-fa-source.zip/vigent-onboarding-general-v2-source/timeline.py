from pathlib import Path
import json
import math

alignment = json.loads(Path('alignment.json').read_text())
lines = alignment['lines']
fps = 60
frames = math.ceil((alignment['seconds'] + alignment['voiceStart'] + 2.1)*fps)
duration = frames/fps

def at(line, token=None, offset=0, last=False):
    words = lines[line]
    hits = [w for w in words if token is None or token in w['text']]
    word = hits[-1 if last else 0]
    return round(word['start']+offset,3)

sceneStarts={
    'connect':at('connect',offset=-.16),
    'comment':at('comment',offset=-.15),
    'thread':at('comment','میاد',.31),
    'sync':at('sync',offset=-.08),
    'voice':at('consult',offset=-.08),
    'consult':at('consult','اطلاعات',-.22),
    'order':at('order',offset=-.12),
    'woo':at('payment',offset=-.09),
    'card':at('payment','درگاه',-.08,last=True),
    'track':at('track','سفارش',-.19),
    'booking':at('booking',offset=-.03),
    'inbox':at('inbox',offset=-.12),
    'lead':at('lead',offset=-.11),
    'knowledge':at('settings',offset=-.10),
    'behavior':at('settings','رفتار',-.12),
    'improve':at('improve',offset=-.11),
    'install':at('install',offset=-.11),
    'alerts':at('install','نوع',-.10),
    'vigento':at('vigento',offset=-.12),
    'closing':at('closing',offset=-.03),
}
cues={
    'welcome':.33,
    'intro':at('intro','ایجنت',-.26),
    'chip-answer':at('intro','جواب',.04),
    'chip-pay':at('intro','می‌فروشه',.04),
    'chip-rules':at('intro','نوبت',.03),
    'promise':at('promise','ویجِنت',-.16),
    'promise-tray':at('promise','خیلی',-.14),
    'promise-pro':at('promise','حرفه‌ای',-.03),
    'promise-smart':at('promise','هوشمندتر',-.05),
    'promise-be':at('promise','می‌شه',-.18),
    'connect-done':at('connect','وصل',.11),
    'rule-comment':at('connect','کامنت',.04),
    'rule-story':at('connect','استوری',.03),
    'type-comment':at('comment','می‌نویسه',.12),
    'send-comment':at('comment','لینک',.04),
    'trigger':at('comment','جوابش'),
    'jump':at('comment','دایرکت',.07),
    'dm-start':at('comment','میاد',.68),
    'sync-open':at('sync','وردپرس',-.18),
    'sync-stock':at('sync','موجودی'),
    'sync-price':at('sync','قیمت'),
    'sync-spec':at('sync','مشخصات'),
    'sync-orders':at('sync','سفارش'),
    'sync-done':at('sync','همگام',.11),
    'dm-voice':at('consult','ویس',.01),
    'dm-text':at('consult','می‌فهمه',-.12),
    'dm-product':at('consult','مدل',-.09),
    'product-facts':at('consult','سایز',.03),
    'dm-select':at('order',offset=-.26),
    'dm-summary':at('order','سفارش',-.10),
    'dm-confirm':at('order','تأیید',.11),
    'dm-link':at('order','لینک',.10),
    'site-open':at('payment','متصل',.08),
    'site-go':at('payment','پرداخت',.3),
    'bank-open':at('payment','کارت‌به‌کارت',.12),
    'bank-ok':at('payment','تأیید',.05),
    'dm-paid':at('payment','می‌کنه',.21,last=True),
    'dm-later':at('track','سفارش',.04),
    'dm-track':at('track','پیگیری',.12),
    'track-open':at('track','ایجنت',.04),
    'track-live':at('track','ارسال'),
    'track-sync':at('track','اطلاعات',.08),
    'dm-status':at('track','فروشگاه',.04),
    'days':at('booking','خالی',-.12),
    'book-slot':at('booking','نشون',.03),
    'book-done':at('booking','ثبت',.06),
    'inbox-rows':at('inbox','صندوق',-.12),
    'handoff':at('inbox','خلاصه',.06),
    'lead-switch':at('lead','قبل',.05),
    'lead-name':at('lead','نام',.05),
    'lead-phone':at('lead','موبایل',.05),
    'lead-send':at('lead','بگیری',.28),
    'crm-contact':at('lead','سی‌آر',.06),
    'crm-success':at('lead','ثبت',.12),
    'kb-site':at('settings','سایت',.10),
    'kb-file':at('settings','فایل',.04),
    'kb-faq':at('settings','دانش',.39),
    'tone':at('settings','لحنش',-.13),
    'hello':at('settings','لحنش',.41),
    'escalate':at('settings','تنظیم',-.10),
    'review-switch':at('improve','روشن',.06),
    'review-state':at('improve','گفتگوها',-.11),
    'review-source':at('improve','ضعف',-.13),
    'review-suggestion':at('improve','پیشنهاد',.13),
    'install-action':at('install','نصب',.05),
    'enable-action':at('install','روشن',.08),
    'desktop-toast':at('install','سفارش',.17),
    'phone-toast':at('install','گفتگو',-.12),
    'pref-handoff':at('install','تنظیمات',.13),
    'vigento-query':at('vigento','درباره',.10),
    'vigento-answer':at('vigento','فروش',.53),
    'vigento-change':at('vigento','تنظیم',.07),
    'vigento-proposal':at('vigento','کمک',.12),
}

chunks={
    'welcome':[],
    'intro':[(0,7),(7,19)],
    'promise':[],
    'connect':[(0,5),(5,20)],
    'comment':[(0,11)],
    'sync':[(0,7),(7,14)],
    'consult':[(0,7),(7,17)],
    'order':[(0,14)],
    'payment':[(0,8),(8,23)],
    'track':[(0,6),(6,20)],
    'booking':[(0,16)],
    'inbox':[(0,7),(7,20)],
    'lead':[(0,10),(10,15)],
    'settings':[(0,11),(11,22)],
    'improve':[(0,11),(11,22)],
    'install':[(0,8),(8,20),(20,28)],
    'vigento':[(0,6),(6,13),(13,22)],
    'closing':[],
}
captions=[]
for key,slices in chunks.items():
    words=lines[key]
    for before,after in slices:
        entries=words[before:after]
        if not entries: continue
        start=max(captions[-1]['time']+.32 if captions else 0, entries[0]['start'])
        end=min(duration,words[after]['start'] if after<len(words) else entries[-1]['end']+.33)
        display=' '.join(w['text'] for w in entries).rstrip('،.')
        display=display.replace('سی‌آر‌اِم','CRM')
        captions.append(dict(time=round(start,3),until=round(max(start+.28,end),3),text=display))
for a,b in zip(captions,captions[1:]):
    a['until']=min(a['until'],b['time']-.035)
sounds={
    'welcome':'open','chip-answer':'tick','chip-pay':'tick','chip-rules':'tick',
    'promise-tray':'whoosh','promise-pro':'tick','promise-smart':'open',
    'connect-done':'done','rule-comment':'tick','rule-story':'tick','send-comment':'send','trigger':'tap','dm-start':'reply',
    'sync-open':'card','sync-stock':'tick','sync-price':'tick','sync-spec':'tick','sync-orders':'tick','sync-done':'done',
    'dm-voice':'send','dm-text':'tick','dm-product':'card','dm-select':'send','dm-summary':'card',
    'dm-confirm':'send','dm-link':'reply','site-open':'card','site-go':'tap','bank-open':'card',
    'bank-ok':'tick','dm-paid':'done','dm-track':'send','track-live':'tick','dm-status':'reply',
    'book-slot':'tap','book-done':'done','inbox-rows':'tick','handoff':'reply',
    'lead-switch':'tap','lead-send':'send','crm-success':'done','kb-site':'tick','kb-file':'tick','tone':'tick',
    'review-switch':'tap','review-source':'tap','review-suggestion':'card',
    'install-action':'tap','enable-action':'tick','desktop-toast':'reply','phone-toast':'reply',
    'pref-handoff':'tap','vigento-query':'send','vigento-answer':'reply','vigento-change':'send','vigento-proposal':'card',
}
events=[dict(key=k,time=v,sound=sounds[k]) for k,v in cues.items() if k in sounds]
events.extend(dict(key=k,time=sceneStarts[k],sound=s) for k,s in
              [('connect','whoosh'),('comment','whoosh'),('booking','whoosh'),('behavior','tap'),('install','whoosh'),('closing','open')])
episode=dict(id='general',fps=fps,frames=frames,duration=duration,closeAt=sceneStarts['closing'],
    cues=cues,sceneStarts=sceneStarts,captions=captions,events=sorted(events,key=lambda x:x['time']),
    scenes=[dict(id='one-take',start=0,voiceStart=alignment['voiceStart'],track='general.pcm')])
timing={'general':episode}
Path('timing.json').write_text(json.dumps(timing,ensure_ascii=False,indent=2)+'\n')
Path('visual/timing.js').write_text('window.SERIES='+json.dumps(timing,ensure_ascii=False,separators=(',',':'))+';\n')
print(f'{duration:.3f}s, {frames} frames, {len(cues)} actions')
for item in captions: print(f"{item['time']:5.2f}–{item['until']:5.2f} {item['text']}")
