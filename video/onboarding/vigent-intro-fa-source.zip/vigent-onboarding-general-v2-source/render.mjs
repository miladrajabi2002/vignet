import { spawn } from 'node:child_process';
import { access, link, mkdir, mkdtemp, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { tmpdir } from 'node:os';
import { setTimeout as pause } from 'node:timers/promises';

const root = dirname(fileURLToPath(import.meta.url));
const timing = JSON.parse(await readFile(join(root, 'timing.json'), 'utf8'));
const chromePath = process.env.VIGENT_CHROMIUM || '/root/.cache/ms-playwright/chromium-1140/chrome-linux/chrome';
const WIDTH = 1920;
const HEIGHT = 1080;

async function launch(id) {
  const profile = await mkdtemp(join(tmpdir(), 'vigent-film-chrome.'));
  const child = spawn(chromePath, [
    '--headless=new', '--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu',
    '--remote-debugging-pipe', '--hide-scrollbars', '--disable-extensions', '--disable-background-networking',
    '--no-first-run', '--no-default-browser-check', '--mute-audio', '--allow-file-access-from-files',
    '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
    '--run-all-compositor-stages-before-draw',
    '--force-color-profile=srgb', '--lang=fa', '--window-size=1920,1080', '--user-data-dir=' + profile,
  ], { stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe'] });

  const requests = new Map();
  let sequence = 0;
  let buffer = '';
  let log = '';
  child.stderr.setEncoding('utf8').on('data', (chunk) => {
    log = (log + chunk).slice(-4000);
  });
  const closed = new Promise((resolve) => {
    child.once('exit', (code) => {
      const error = new Error('Chromium exited (' + code + ') ' + log);
      for (const pending of requests.values()) pending.reject(error);
      requests.clear();
      resolve();
    });
  });

  for (const stream of [child.stdio[3], child.stdio[4]]) {
    stream.on('error', () => {});
  }
  child.stdio[4].setEncoding('utf8').on('data', (chunk) => {
    buffer += chunk;
    let boundary;
    while ((boundary = buffer.indexOf('\u0000')) !== -1) {
      const message = JSON.parse(buffer.slice(0, boundary));
      buffer = buffer.slice(boundary + 1);
      const pending = requests.get(message.id);
      if (!pending) continue;
      requests.delete(message.id);
      if (message.error) pending.reject(new Error(pending.method + ' ' + message.error.message));
      else pending.resolve(message.result);
    }
  });

  function call(method, params = {}, sessionId) {
    return new Promise((resolve, reject) => {
      const id = ++sequence;
      const timeout = setTimeout(() => {
        requests.delete(id);
        reject(new Error(method + ' timed out'));
      }, 20000);
      requests.set(id, {
        method,
        resolve(result) { clearTimeout(timeout); resolve(result); },
        reject(error) { clearTimeout(timeout); reject(error); },
      });
      child.stdio[3].write(JSON.stringify({id, method, params, sessionId}) + '\u0000');
    });
  }

  async function close() {
    if (child.exitCode === null && child.signalCode === null) {
      await Promise.race([call('Browser.close').catch(() => {}), closed, pause(1500)]);
    }
    if (child.exitCode === null) child.kill('SIGTERM');
    await closed;
    await rm(profile, {recursive:true, force:true, maxRetries:4, retryDelay:50});
  }

  try {
    const { targetId } = await call('Target.createTarget', {url: 'about:blank'});
    const { sessionId } = await call('Target.attachToTarget', {targetId, flatten: true});
    const pageCall = (method, params) => call(method, params, sessionId);
    await pageCall('Page.enable');
    await pageCall('Emulation.setDeviceMetricsOverride', {
      width: WIDTH, height: HEIGHT, deviceScaleFactor: 1, mobile: false,
      screenWidth: WIDTH, screenHeight: HEIGHT,
    });
    await pageCall('Page.navigate', {url: pathToFileURL(join(root, 'visual/index.html')).href + '?id=' + id});
    async function evaluate(expression, awaitPromise = false) {
      const response = await pageCall('Runtime.evaluate', {expression, awaitPromise, returnByValue: true});
      if (response.exceptionDetails) throw new Error(response.exceptionDetails.exception?.description || response.exceptionDetails.text);
      return response.result.value;
    }
    for (let i = 0; i < 80; i++) {
      if (await evaluate('Boolean(window.ready)')) break;
      if (i === 79) throw new Error('Film script did not load');
      await pause(90);
    }
    await evaluate('window.ready', true);
    async function screenshot(format) {
      const response = await pageCall('Page.captureScreenshot', {
        format, ...(format === 'jpeg' ? {quality: 95} : {}), optimizeForSpeed: true, fromSurface: true,
      });
      return Buffer.from(response.data, 'base64');
    }
    return { evaluate, screenshot, close };
  } catch (error) {
    await close();
    throw error;
  }
}

async function checkSides(browser,id) {
  const s=await browser.evaluate('window.audit()');
  console.log(id,s.keys,'motion frames · summary',s.summary.toFixed(2),'confirm',s.confirm.toFixed(2),'pay',s.pay.toFixed(2));
}

async function preview(id, givenTimes) {
  const browser = await launch(id);
  try {
    await checkSides(browser, id);
    const episode = timing[id];
    const checkpoint = givenTimes.length ? givenTimes : [1.10,episode.beats.chips.at(-1)+.22,episode.beats.test+.7,episode.beats.chat.catalogue+1.1,episode.beats.chat.summary+.8,episode.beats.chat.transfer+1.25,episode.beats.chat.notice+.66,episode.beats.chat.done+.70,episode.beats.knowledge+.73,episode.beats.end+1.25];
    for (let i = 0; i < checkpoint.length; i++) {
      const time = Math.max(0, Math.min(episode.duration - .02, checkpoint[i]));
      await browser.evaluate('window.seek(' + time.toFixed(6) + ')');
      const image = await browser.screenshot('jpeg');
      const filename = id + '-' + String(i + 1).padStart(2,'0') + '-' + time.toFixed(2) + '.jpg';
      await writeFile(join(root, 'stills', filename), image);
    }
    console.log(id, checkpoint.length, 'frames sampled');
  } finally {
    await browser.close();
  }
}

async function renderLane(id, index, frames) {
  const browser = await launch(id);
  const episode = timing[id];
  try {
    if (index === 0) await checkSides(browser,id);
    const listed = await browser.evaluate('window.keyFrames');
    const start = Math.floor(index * listed.length / 2);
    const end = Math.floor((index + 1) * listed.length / 2);
    for (let i=start; i<end; i++) {
      const frame = listed[i];
      const filename = 'f' + String(frame).padStart(5,'0') + '.jpg';
      const path=join(frames,filename);
      const saved=await readFile(path).catch(()=>null);
      if (!saved || saved.length<4096 || saved.at(-2)!==255 || saved.at(-1)!==217) {
        await browser.evaluate('window.seek(' + (frame/episode.fps).toFixed(8) + ')');
        await writeFile(path,await browser.screenshot('jpeg'));
      }
      if ((i-start+1)%220===0 || i+1===end) console.log('Render',index+1,(i-start+1)+'/'+(end-start));
    }
    return listed.slice(start,end);
  } finally {
    await browser.close();
  }
}

async function render(id) {
  const episode = timing[id];
  const frames = join(root,'frames-'+id);
  await mkdir(frames,{recursive:true});
  const results = await Promise.allSettled([renderLane(id,0,frames),renderLane(id,1,frames)]);
  for (const result of results) if(result.status==='rejected') throw result.reason;
  const listed=results.flatMap(result=>result.value);
  const framePath=frame=>join(frames,'f'+String(frame).padStart(5,'0')+'.jpg');
  for(let index=0;index<listed.length;index++){
    const start=listed[index],stop=listed[index+1]??episode.frames;
    for(let frame=start+1;frame<stop;frame++)await link(framePath(start),framePath(frame)).catch(error=>{
      if(error.code!=='EEXIST')throw error;
    });
  }
  await writeFile(join(frames,'timeline-ready'),String(episode.frames));
  return frames;
}

function run(cmd, args) {
  return new Promise((resolve,reject) => {
    const process = spawn(cmd,args,{stdio:['ignore','inherit','inherit']});
    process.once('error',reject);
    process.once('exit',code => code === 0 ? resolve() : reject(new Error(cmd + ' exited with ' + code)));
  });
}
async function encode(id,frames) {
  const clip=timing[id];
  if(Number(await readFile(join(frames,'timeline-ready'),'utf8'))!==clip.frames)throw Error('Frame sequence incomplete');
  const temporary=join(root,'finished',id+'.tmp.mp4');
  await run('ffmpeg',[
    '-nostdin','-hide_banner','-loglevel','error','-y',
    '-threads','3','-f','image2','-framerate',String(clip.fps),'-start_number','0','-i',join(frames,'f%05d.jpg'),
    '-i',join(root,'mixes',id+'.m4a'),'-map','0:v:0','-map','1:a:0',
    '-filter_threads','2','-vf','scale=in_color_matrix=bt601:in_range=pc:out_color_matrix=bt709:out_range=tv,format=yuv420p,setsar=1',
    '-c:v','libx264','-preset','veryfast','-crf','18','-profile:v','high','-level','4.2','-threads','3',
    '-g','120','-video_track_timescale','60000','-c:a','copy','-movflags','+faststart',
    '-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',temporary,
  ]);
  await rename(temporary,join(root,'finished',id+'.mp4'));
  console.log('Encoded whole film',id,clip.frames);
  await rm(frames,{recursive:true});
}

async function repair(id, start, end) {
  const browser = await launch(id);
  const frames = join(root,'frames-'+id);
  try {
    const listed = await browser.evaluate('window.keyFrames');
    const selected = listed.filter(frame=>frame/timing[id].fps>=start && frame/timing[id].fps<=end);
    for(const frame of selected) {
      const time=frame/timing[id].fps;
      const name=join(frames,'f'+String(frame).padStart(5,'0')+'.jpg');
      await access(name);
      await browser.evaluate('window.seek('+time.toFixed(8)+')');
      await writeFile(name+'.next',await browser.screenshot('jpeg'));
      await rename(name+'.next',name);
    }
    console.log(selected.length,'revised transition frames');
  } finally {
    await browser.close();
  }
}
const [mode, requested, ...extra] = process.argv.slice(2);
const ids = requested === 'all' ? Object.keys(timing) : requested.split(',');
if (ids.some(id => !timing[id])) throw new Error('Unknown film ID');
const limit = Number(process.env.VIGENT_LANES || 2);
const operations = [...ids];
let failed = 0;
await Promise.all(Array.from({length: Math.min(limit,operations.length)}, async () => {
  while (operations.length) {
    const id = operations.shift();
    try {
      if (mode === 'stills') await preview(id,extra.map(Number));
      else if (mode === 'frames') await encode(id,await render(id));
      else if (mode === 'repair') await repair(id,Number(extra[0]),Number(extra[1]));
      else if (mode === 'capture') await render(id);
      else if (mode === 'encode') await encode(id,join(root,'frames-' + id));
      else throw new Error('Use stills, capture, frames, or encode');
    } catch (error) {
      failed++;
      console.error(id,error?.stack || error);
    }
  }
}));
if (failed) process.exitCode = 1;
