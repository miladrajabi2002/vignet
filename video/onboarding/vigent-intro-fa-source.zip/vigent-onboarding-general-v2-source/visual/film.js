'use strict';
const ds = window.SERIES.general;
const {cues, sceneStarts, captions, events, duration, fps, frames} = ds;
const $ = id => document.getElementById(id);
const put = (id, html) => { $(id).innerHTML = html; };
const clamp = (x, low=0, high=1) => Math.max(low,Math.min(high,x));
const range = (t, start, length) => clamp((t-start)/length);
function setMarkup(node,markup){
  if(node.dataset.rendered!==markup){
    node.dataset.rendered=markup;
    node.innerHTML=markup;
  }
}
const out = p => 1-(1-p)**3;
const inOut = p => p*p*(3-2*p);
const lerp = (a,b,v) => a+(b-a)*v;
const iconPaths = {
  check:'M5 12l4 4L19 6',
  double:'M2 12l4 4L16 6m-4 11 9-9',
  instagram:'M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm9 10a4 4 0 1 1-8 0 4 4 0 0 1 8 0Zm2-6h.01',
  chat:'M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7A8.4 8.4 0 0 1 4 11.5a8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z',
  story:'M7 7H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2l-2-3H9L7 7Zm8.1 6a3.1 3.1 0 1 1-6.2 0 3.1 3.1 0 0 1 6.2 0Z',
  spark:'M12 2c.8 5.3 3.2 7.9 9 9-5.8 1.2-8.2 3.7-9 9-.9-5.3-3.4-7.8-9-9 5.6-1.1 8.1-3.7 9-9Zm7 15v5m2.5-2.5h-5',
  cart:'M3 3h2l2 13h12l2-9H6m3 13h.01m8 0h.01',
  link:'M10 14l4-4m-6 6-1.4 1.4a3.5 3.5 0 0 1-5-5L6 8a3.5 3.5 0 0 1 5 0m5 0 1.4-1.4a3.5 3.5 0 0 1 5 5L18 16a3.5 3.5 0 0 1-5 0',
  right:'m10 6 6 6-6 6',
  left:'m14 6-6 6 6 6',
  send:'m21 3-7 18-4-8-8-4 19-6ZM10 13 21 3',
  file:'M6 2h8l4 4v16H6zM14 2v5h5m-9 5h4m-4 4h4',
  mic:'M9 5a3 3 0 0 1 6 0v6a3 3 0 0 1-6 0zm-4 5v1a7 7 0 0 0 14 0v-1m-7 8v4m-4 0h8',
  play:'m8 5 12 7-12 7z',
  clock:'M12 7v5l3 2m6-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z',
  cal:'M4 5h16a1 1 0 0 1 1 1v14H3V6a1 1 0 0 1 1-1Zm3-2v4m10-4v4M3 10h18',
  inbox:'M6 5h12l4 8v6H2v-6l4-8ZM2 13h6l2 3h4l2-3h6',
  user:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2m12-14a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z',
  globe:'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0ZM2 12h20M12 2a16 16 0 0 0 0 20m0-20a16 16 0 0 1 0 20',
  card:'M3 5h18v14H3zm0 5h18m-14 5h3',
  bank:'M3 9 12 3l9 6H3Zm2 11h14M7 11v6m5-6v6m5-6v6',
  secure:'M12 22s7-3.5 7-10V6l-7-3-7 3v6c0 6.5 7 10 7 10Zm-3-10 2.1 2.1 4-4',
  tune:'M4 7h16M4 17h16M8 4v6m8 4v6',
  book:'M3 5h6a3 3 0 0 1 3 3v12a3 3 0 0 0-3-3H3Zm18 0h-6a3 3 0 0 0-3 3v12a3 3 0 0 1 3-3h6Z',
  plus:'M12 5v14M5 12h14',
  package:'M12 22 3 17V7l9-5 9 5v10l-9 5ZM3 7l9 5 9-5m-9 5v10m-4.5-12.5 9-5',
  sync:'M20 7h-5m5 0V2M4 17h5m-5 0v5M3.6 10a8.7 8.7 0 0 1 14.5-5.7L20 7M4 17l1.9 2.7A8.7 8.7 0 0 0 20.4 14',
  truck:'M2 5h13v12H2zm13 4h4l3 4v4h-7M7 17a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm11 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z',
  desktop:'M2 4h20v13H2zm10 13v4m-5 0h10',
  phone:'M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm5 16h.01',
  bell:'M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9m-8 12a2.5 2.5 0 0 0 4 0',
  list:'M8 6h12M8 12h12M8 18h12M4 6h.1M4 12h.1M4 18h.1',
  chart:'M3 3v18h18M8 16v-4m5 4V6m5 10v-6',
  corner:'M20 7v6a4 4 0 0 1-4 4H4m5-5-5 5 5 5',
  location:'M12 21s6-5.4 6-11a6 6 0 1 0-12 0c0 5.6 6 11 6 11zm0-13a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z',
};
const icon = key => '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="'+iconPaths[key]+'"/></svg>';
const mark = (key, soft=false) => '<span class="mark'+(soft?' soft':'')+'">'+icon(key)+'</span>';
const flag = (text, active=false) => '<span class="flag'+(active?' active':'')+'">'+(active?icon('check'):'')+text+'</span>';
function header(key,title,sub,side='') {
  return '<header class="face-header">'+mark(key)+'<div><div class="lead">'+title+'</div>'+(sub?'<small>'+sub+'</small>':'')+'</div>'+side+'</header>';
}
const skin = content => '<div class="skin" dir="rtl">'+content+'</div>';
const tag = (key,text) => '<span class="tag">'+icon(key)+text+'</span>';
put('bridge',icon('send')+'<span>ارسال به دایرکت</span>');
const chipLabels=[['chat','پاسخ مشتری'],['cart','فروش و پرداخت'],['cal','رزرو نوبت']];
put('chips',chipLabels.map(([key,text],i)=>'<span class="chip" id="chip-'+i+'">'+icon(key)+text+'</span>').join(''));
const content = {
  connect: ['اتصال اینستاگرام','اینستاگرامت رو<br>وصل کن','ایجنت از همین‌جا به پیام‌ها، کامنت‌ها و استوری‌هات می‌رسه.'],
  comment: ['اتوماسیون پیج','از کامنت<br>به دایرکت','با یک کلمه زیر پست، گفتگوی خرید خودش شروع می‌شه.',[['chat','کامنت به دایرکت'],['story','پاسخ به استوری']]],
  sync: ['افزونهٔ وردپرس','ووکامرس به‌روز می‌مونه','ایجنت از دادهٔ فروشگاه جواب می‌ده.'],
  voice: ['مشاوره در دایرکت','ویس فارسی رو<br>می‌فهمه','مشتری می‌تونه با ویس دربارهٔ مدل، سایز یا موجودی بپرسه.'],
  consult: ['مشاوره در دایرکت','پیشنهاد از<br>کاتالوگ خودت','ایجنت با توجه به خواستهٔ مشتری، مدل و سایز پیشنهاد می‌ده.',[['check','موجودی'],['check','قیمت'],['check','مشخصات']]],
  order: ['خرید در دایرکت','از انتخاب تا<br>لینک پرداخت','ایجنت مبلغ سفارش و ارسال رو جمع می‌زنه. مشتری همون‌جا تأیید می‌کنه.'],
  woo: ['پرداخت با درگاه فروشگاه','درگاه سایت خودت','برای فروشگاه ووکامرسِ متصل'],
  card: ['پرداخت با ویجنت','کارت‌به‌کارت خودکار','تطبیق واریز با پیامک بانک'],
  track: ['پشتیبانی فروشگاه','پیگیری سفارش','وضعیت و کد رهگیری از سفارشِ همگام‌شده'],
  booking: ['رزرو نوبت','زمان مشاوره<br>رو رزرو کن','ایجنت وقت خالی رو می‌بینه و با انتخاب مشتری نوبت ثبت می‌کنه.'],
  inbox: ['صندوق پیام‌ها','همهٔ گفتگوها<br>یک‌جا','اگه گفتگو به همکار نیاز داشت، با خلاصه تحویل تیم می‌شه.',[['inbox','صندوق مشترک'],['user','تحویل به همکار']]],
  lead: ['ثبت اطلاعات مشتری','نام و موبایل<br>قبل از پاسخ','فرم قبل از چت رو که روشن کنی، اطلاعات مشتری توی CRM ثبت می‌شه.'],
  knowledge: ['تنظیمات ایجنت','از اطلاعات<br>خودت جواب بده','دانش ایجنت رو از سایت، فایل یا جواب‌های آماده بساز.'],
  behavior: ['تنظیمات ایجنت','ایجنت با لحن<br>کسب‌وکار تو','پیام شروع و قواعد سپردن گفتگو به همکار رو هم می‌تونی تغییر بدی.'],
  improve: ['پیشنهادهای بهبود','از گفتگوها<br>یاد می‌گیره','با روشن کردن بررسی روزانه، پیشنهادهای اصلاح رو توی پنل می‌بینی.'],
  install: ['نصب پنل ویجنت','هم روی گوشی،<br>هم کامپیوتر','پنل رو مثل یک برنامه نصب کن.'],
  alerts: ['تنظیمات اعلان‌ها','خبرهای مهم<br>بهت می‌رسن','دستگاه‌ها و نوع اعلان رو از «تنظیمات ← اعلان‌ها» مدیریت کن.'],
  vigento: ['دستیار پنل','ویجنتو،<br>کنار خودت','از فروش و گفتگوها بپرس یا برای تنظیم ایجنت کمک بگیر.'],
};
put('notes',Object.entries(content).map(([key,[kicker,title,description,tags]])=>
  '<section id="note-'+key+'" class="note'+(['sync','woo','card','track'].includes(key)?' compact':'')+'">'+
  '<div class="kicker">'+kicker+'</div><h2>'+title+'</h2><p>'+description+'</p>'+
  (tags?'<div class="tags">'+tags.map(([type,label])=>tag(type,label)).join('')+'</div>':'')+'</section>').join(''));

function rule(key,title,detail,extra,id) {
  return '<div class="rule" id="'+id+'">'+mark(key,true)+'<div><b>'+title+'</b><br><small>'+detail+'</small></div>'+flag(extra)+'</div>';
}
put('integrate',skin(header('instagram','اتصال کانال‌ها','اینستاگرام')+
  '<div class="integration-body"><div class="integration-head">'+mark('instagram')+
  '<div><h3>فروشگاه کتان</h3><small dir="ltr">@katan.shop · نمونه</small></div>'+
  '<div class="action-slot"><b id="connect-action" class="enroll">'+icon('link')+'اتصال پیج</b><b id="connected" class="enrolled">'+icon('check')+'وصل شد</b></div></div>'+
  '<div class="rule-list">'+rule('chat','اتوماسیون کامنت','پیام خصوصی با کلمهٔ کلیدی','دایرکت','integration-comment')+
  rule('story','اتوماسیون استوری','پاسخ به ریپلای استوری','استوری','integration-story')+'</div>'+
  '<div class="wire" id="integrated">'+icon('secure')+'کانال به ایجنت وصل شد<span class="line"></span></div></div>'));

put('automate',skin(header('spark','اتوماسیون اینستاگرام','فروشگاه کتان',flag('قانون فعال',true))+
  '<div class="automation-body"><div class="post"><div class="post-top">'+mark('instagram',true)+'فروشگاه کتان</div>'+
  '<div class="post-image"></div><div class="post-foot"><b>کت کلاسیک زنانه</b><div id="sample-comment" class="sample-comment">'+icon('chat')+'سارا · «لینک»</div></div></div>'+
  '<div class="rules-card"><h3>قانون پاسخ خودکار</h3><div class="rule-stack"><div class="rule-step">'+icon('chat')+'کامنت حاوی «لینک»</div>'+
  '<div id="rule-divider" class="rule-divider"></div><div class="rule-step" id="trigger">'+icon('send')+'ارسال پیام در دایرکت</div></div>'+
  '<div class="rule-alt">'+icon('story')+'قابل تنظیم برای استوری</div></div></div>'+
  '<div id="jump" class="jump-label">'+icon('chat')+'پیام برای سارا فرستاده شد</div>'));

const nativeTemplate = document.createElement('template');
nativeTemplate.innerHTML = window.VIGENT_DEMO.chat;
const productRail = nativeTemplate.content.querySelector('[data-message="catalogue"] article').closest('section');
const products = '<div id="catalogue-native"><div class="native-app" dir="rtl">'+productRail.outerHTML+'</div></div>';
const wave = Array.from({length:26},(_,i)=>'<i style="height:'+Math.round(8+26*Math.abs(Math.sin(i*1.8)*Math.cos(i*.37)))+'px"></i>').join('');
const messages = [
  ['dm-start','out','سلام سارا! این کت کلاسیکه. اگه برای انتخاب رنگ و سایز کمک می‌خوای، همین‌جا بهم بگو.'],
  ['dm-voice','in','<span class="waveform"><span class="play">'+icon('play')+'</span><span id="wave">'+wave+'</span><time class="waveform-time">۰:۰۵</time></span>'],
  ['dm-text','out','<span class="show-transcript">'+icon('mic')+'متن ویس</span>«برای مهمونی دنبال کت رسمی مشکی‌ام. سایز ۴۰ موجوده؟»'],
  ['dm-product','out','بله، کت کلاسیک مشکی سایز ۴۰ موجوده. برای مهمونی رسمی همین مدل رو پیشنهاد می‌کنم.'+products],
  ['dm-select','in','همین کت مشکی سایز ۴۰ رو می‌خوام.'],
  ['dm-summary','out','<div class="summary-title">خلاصهٔ سفارش</div><div class="summary-line"><span>کت کلاسیک مشکی · ۴۰</span><span>۲٬۴۸۰٬۰۰۰</span></div><div class="summary-line"><span>ارسال پستی</span><span>۷۰٬۰۰۰</span></div><div class="summary-line"><span>جمع</span><span>۲٬۵۵۰٬۰۰۰ تومان</span></div>'],
  ['dm-confirm','in','تأیید می‌کنم.'],
  ['dm-link','out','لینک پرداخت سفارشت آماده‌ست.<span class="pay-link">'+icon('card')+'پرداخت سفارش'+icon('left')+'</span>'],
  ['dm-paid','out','<span class="receipt">'+icon('check')+'پرداخت سفارشت تأیید شد.</span>لطفاً نشانی ارسال رو بفرست.'],
  ['dm-later','divider','بعد از آماده‌سازی سفارش'],
  ['dm-track','in','سلام، سفارش ۱۰۴۸ ارسال شده؟'],
  ['dm-status','out','بله، سفارش ۱۰۴۸ تحویل پست شد. <div class="tracking"><b>کد رهگیری</b><span dir="ltr">۲۴۸۹•••۱۳</span></div>'],
];
put('conversation',skin(header('chat','دایرکت فروشگاه کتان','گفتگو با سارا',flag('ایجنت فعاله',true))+
  '<div class="thread-viewport"><div class="thread" id="thread">'+messages.map(([key,side,body])=>
    '<div class="message '+side+'" id="'+key+'"><div class="bubble'+(side==='in'?' mine':'')+'">'+body+'</div></div>').join('')+
  '</div><div id="voice-listening">'+icon('mic')+'<span>در حال فهمیدن ویس</span><i></i><i></i><i></i></div></div><div class="composer">'+icon('send')+'<div id="composer-field" class="field">پیام بنویس…</div>'+icon('mic')+'</div>'));

put('site-pay','<div class="pay-shell"><div class="pay-head">'+mark('globe',true)+'پرداخت روی سایت فروشگاه</div>'+
  '<div class="checkout-native">'+window.VIGENT_DEMO.merchant.replaceAll('A7K2Q9', '۱۰۴۸')+'</div></div>');
put('card-pay','<div class="pay-shell"><div class="pay-head">'+mark('card',true)+'درگاه ویجنت</div>'+
  '<div class="bank-row"><span>مبلغ واریز</span><strong>۲٬۵۵۰٬۰۳۷ تومان</strong></div>'+
  '<div class="bank-row"><span>کارت فروشگاه کتان</span><strong dir="ltr">•••• ۴۰۲۱</strong></div>'+
  '<div id="bank-dots" class="bank-row"><span>در انتظار پیامک بانک</span>'+icon('clock')+'</div>'+
  '<div id="bank-ok" class="bank-match">'+icon('check')+'پیامک بانک با واریز تطبیق داده شد</div></div>');

const days = [['شنبه','۱۵'],['یکشنبه','۱۶'],['دوشنبه','۱۷'],['سه‌شنبه','۱۸'],['چهارشنبه','۱۹']];
put('booking',skin(header('cal','تقویم رزرو','مشاورهٔ انتخاب استایل')+
  '<div class="booking-body"><div class="calendar-card"><h3>زمان‌های خالی این هفته</h3><p>یک بازهٔ ۳۰ دقیقه‌ای برای مشاوره انتخاب کنید.</p>'+
  '<div class="calendar-week">'+days.map(([d,n],i)=>'<span class="day" id="day-'+i+'"><span>'+d+'</span><b>'+n+'</b></span>').join('')+'</div>'+
  '<div class="hours" id="hours"><span class="slot">۱۶:۰۰</span><span class="slot target" id="book-slot">'+icon('clock')+'۱۷:۰۰</span><span class="slot">۱۸:۳۰</span></div></div>'+
  '<div id="book-done" class="book-check">'+icon('check')+'مشاورهٔ سارا رزرو شد · سه‌شنبه، ساعت ۱۷:۰۰</div></div>'));
const channels = [['instagram','اینستاگرام'],['send','تلگرام'],['chat','بله'],['chat','روبیکا'],['globe','سایت']];
const inboxRow = (key,name,desc,status,id) => '<div class="inbox-row" id="'+id+'">'+mark(key,true)+'<div><b>'+name+'</b><small>'+desc+'</small></div>'+flag(status)+'</div>';
put('inbox',skin(header('inbox','صندوق پیام‌ها','همهٔ کانال‌ها')+
  '<div class="inbox-body"><div class="channels">'+channels.map(([key,label])=>'<span class="channel">'+icon(key)+label+'</span>').join('')+'</div>'+
  inboxRow('instagram','سارا','اینستاگرام · پیگیری سفارش کت','خرید','inbox-sara')+
  inboxRow('send','نیلوفر','تلگرام · تغییر زمان مشاوره','رزرو','inbox-niloofar')+
  inboxRow('globe','الهام','سایت · شرایط تعویض','سؤال','inbox-elham')+
  '<div id="handoff-card" class="handoff"><b>'+icon('user')+' سپرده شد به تیم فروش</b><p>خلاصه: پرداخت سارا تأیید شده. پیگیری نشانی ارسال باقی مونده.</p></div></div>'));
const source = (key,label,detail,id) => '<div class="source" id="'+id+'">'+mark(key,true)+'<div><b>'+label+'</b><small>'+detail+'</small></div>'+flag('آماده',true)+'</div>';
const control = (key,label,value,id) => '<div class="control" id="'+id+'"><div class="control-label">'+icon(key)+'<b>'+label+'</b></div><div class="control-field">'+value+'</div></div>';
put('settings',skin(header('tune','تنظیمات ایجنت','ایجنت فروشگاه کتان')+
  '<div class="settings-body"><div class="settings-tabs"><div class="settings-tab" id="tab-knowledge">'+icon('book')+'دانش</div>'+
  '<div class="settings-tab" id="tab-behavior">'+icon('tune')+'رفتار و پاسخ</div></div>'+
  '<div class="settings-layout"><div id="kb" class="settings-page"><h3>منابع دانش</h3><p>'+icon('plus')+' افزودن منبع جدید</p>'+
  source('globe','وب‌سایت فروشگاه','صفحه‌های محصولات و اطلاعات ارسال','kb-site')+
  source('file','کاتالوگ PDF','مدل‌ها، عکس‌ها و راهنمای سایز','kb-file')+
  source('chat','پرسش‌های پرتکرار','شرایط تعویض و زمان تحویل','kb-faq')+'</div>'+
  '<div id="behavior" class="settings-page"><h3>نحوهٔ پاسخ‌گویی</h3><p>ایجنت با این تنظیمات به مشتری جواب می‌ده.</p>'+
  control('chat','لحن','دوستانه و حرفه‌ای','tone')+
  control('spark','پیام خوش‌آمدگویی','سلام! برای انتخاب محصول یا پیگیری سفارش اینجام.','hello')+
  control('user','سپردن گفتگو به همکار','درخواست مشتری یا نیاز به بررسی بیشتر','escalate')+'</div></div></div>'));


const brandMark = '<span class="app-mark"><img src="vigent-app.png" width="42" height="42" alt=""></span>';
const switchTrack = id => '<span id="'+id+'" class="switch"><i></i></span>';
const softRow = (key,title,detail,tail='',id='') => '<div class="panel-row"'+(id?' id="'+id+'"':'')+'>'+mark(key,true)+
  '<div class="row-info"><b>'+title+'</b>'+(detail?'<small>'+detail+'</small>':'')+'</div>'+tail+'</div>';
const footLabel = (key,text,id) => '<div id="'+id+'" class="accent-foot">'+icon(key)+text+'</div>';
const badge = (key,text)=>'<span class="tiny-badge">'+icon(key)+text+'</span>';

function syncRow(key,label,before,after,id){
  return '<div class="sync-row" id="'+id+'">'+icon(key)+'<span>'+label+'</span>'+
    '<div class="sync-value"><b class="sync-from">'+before+'</b><b class="sync-to">'+after+'</b></div></div>';
}
put('woo-sync','<div class="pay-shell sync-shell"><div class="pay-head">'+mark('sync',true)+'افزونهٔ ویجنت برای وردپرس</div>'+
  '<div class="sync-store"><b>ووکامرس · فروشگاه کتان</b>'+flag('متصل',true)+'</div>'+
  syncRow('package','موجودی کت مشکی','۸ عدد','۱۲ عدد','sync-stock')+
  syncRow('card','قیمت','۲٬۵۹۰٬۰۰۰','۲٬۴۸۰٬۰۰۰ تومان','sync-price')+
  syncRow('list','مشخصات','سایز ۳۸','سایز ۳۸ و ۴۰ · مشکی','sync-spec')+
  syncRow('truck','سفارش‌ها','در حال همگام‌سازی','همگام شد','sync-orders')+
  footLabel('check','دادهٔ تازه به ایجنت رسید','sync-done')+'</div>');

put('track-order','<div class="pay-shell tracking-shell"><div class="pay-head">'+mark('truck',true)+'سفارش ووکامرس · ۱۰۴۸</div>'+
  '<div class="track-step done">'+icon('check')+'ثبت سفارش</div>'+
  '<div class="track-step done">'+icon('check')+'آماده‌سازی</div>'+
  '<div class="track-step" id="track-live">'+icon('truck')+'تحویل به پست</div>'+
  footLabel('sync','آخرین وضعیت به ایجنت رسید','track-sync')+'</div>');

put('lead',skin(header('user','فرم مشتری','چت‌لینک فروشگاه کتان')+
  '<div class="lead-body">'+softRow('chat','فرم معرفی قبل از چت','در شروع گفتگو نمایش داده شود',switchTrack('lead-switch'))+
  '<div class="split-lead"><article class="lead-form"><h3>قبل از شروع گفتگو</h3>'+
  '<div class="lead-input"><span>نام</span><b id="lead-name">سارا ک.</b></div>'+
  '<div class="lead-input"><span>شماره موبایل</span><b dir="ltr" id="lead-phone">۰۹۱۲•••••۳۴</b></div>'+
  '<div class="board-button" id="lead-submit">شروع گفتگو '+icon('left')+'</div></article>'+
  '<span id="lead-arrow" class="lead-arrow">'+icon('left')+'</span>'+
  '<article class="lead-crm"><h3>'+icon('user')+' مشتریان · CRM</h3><div id="crm-contact">'+mark('user',true)+
  '<div><b>سارا ک.</b><small dir="ltr">۰۹۱۲•••••۳۴</small></div></div>'+
  footLabel('check','مخاطب ثبت شد','crm-success')+'</article></div></div>'));

put('improve',skin(header('spark','پیشنهادهای بهبود','عملکرد ایجنت فروشگاه کتان')+
  '<div class="improve-body">'+softRow('clock','تحلیل روزانه','مرور گفتگوهای تازه یا به‌روزشده',switchTrack('review-switch'))+
  '<div class="review-state" id="review-state"><div class="review-rail"><i id="review-line"></i></div><span id="review-status">مرور گفتگوها</span></div>'+
  '<div class="review-source" id="review-source">'+badge('chat','نمونه از گفتگو')+'<h3>«برای تعویض سایز چقدر وقت دارم؟»</h3>'+
  '<p>در پاسخ، مهلت تعویض مشخص نشده بود.</p></div>'+
  '<div class="suggestion" id="review-suggestion">'+badge('spark','پیشنهاد اصلاح')+
  '<p>مهلت تعویض سایز رو از سیاست فروشگاه به دانش ایجنت اضافه کن.</p><span class="small-button">پیش‌نمایش اصلاح '+icon('left')+'</span></div></div>'));

const installSite = '<div class="device-address"><i></i><i></i><i></i><span>vigent.ir</span></div>'+
  '<div class="device-app"><div class="device-app-head">'+brandMark+'<b>پنل ویجنت</b>'+icon('bell')+'</div>'+
  '<div class="device-app-items"><span>'+icon('inbox')+' گفتگوها</span><span>'+icon('cart')+' سفارش‌ها</span><span>'+icon('cal')+' رزروها</span></div></div>';
const receiptToast=(id,key,title,detail)=>'<div class="device-toast" id="'+id+'">'+mark(key,true)+'<div><b>'+title+'</b><small>'+detail+'</small></div></div>';
const installPermission='<div class="install-actions"><div class="install-action" id="install-action">'+icon('plus')+'نصب برنامه</div>'+
  '<div class="install-action" id="enable-action">'+icon('bell')+'روشن کردن اعلان‌ها</div></div>';
const preference = (key,text,id) => '<div class="preference">'+icon(key)+'<b>'+text+'</b>'+switchTrack(id)+'</div>';
put('install',skin(header('bell','نصب ویجنت و اعلان‌ها','راهنمای راه‌اندازی پنل')+
  '<div class="install-view" id="install-view"><div class="desktop" id="desktop">'+installSite+
  receiptToast('desktop-toast','cart','سفارش تازه','۲٬۵۵۰٬۰۰۰ تومان · پرداخت تأیید شد')+'</div>'+
  '<div class="device-phone" id="device-phone"><div class="phone-notch"></div><div class="phone-home">'+brandMark+'<b>ویجنت</b></div>'+
  receiptToast('phone-toast','chat','گفتگو به شما سپرده شد','سارا · پیگیری سفارش')+'</div>'+installPermission+'</div>'+
  '<div class="preferences-view" id="preferences-view"><div class="breadcrumb">تنظیمات '+icon('left')+' <b>اعلان‌ها</b></div>'+
  softRow('desktop','دستگاه‌های این حساب','موبایل و کامپیوتر',flag('روشن',true))+
  '<div class="preference-card"><h3>نوع اعلان‌ها</h3>'+
  preference('cart','سفارش و پیش‌سفارش','pref-orders')+
  preference('card','پرداخت و واریز','pref-pay')+
  preference('cal','رزرو و ثبت‌نام','pref-book')+
  preference('chat','انتقال گفتگو به اپراتور','pref-handoff')+'</div></div>'));

put('vigento',skin(header('spark','ویجنتو','دستیار پنل کسب‌وکار')+
  '<div class="vigento-room"><div class="vigento-message user" id="vigento-query">این هفته چند سفارش ثبت شد؟</div>'+
  '<div class="vigento-answer" id="vigento-answer">'+brandMark+'<div><b>۱۸ سفارش ثبت شد.</b><small>۴ سفارش هنوز در انتظار ارسال‌اند.</small></div></div>'+
  '<div class="vigento-message user" id="vigento-change">پیام خوش‌آمد ایجنتم رو بهتر کن.</div>'+
  '<div class="suggestion vigento-suggestion" id="vigento-proposal">'+badge('tune','پیشنهاد تنظیم ایجنت')+
  '<p>«سلام! برای انتخاب محصول یا پیگیری سفارش اینجام.»</p><span class="small-button">بررسی و تأیید تغییر '+icon('left')+'</span></div></div>'+
  '<div class="composer">'+icon('send')+'<div class="field">از ویجنتو بپرس…</div>'+icon('mic')+'</div>'));

function pose(node, opacity, dx=0, dy=0, scale=1) {
  node.style.opacity = String(clamp(opacity));
  node.style.transform = 'translate3d('+dx+'px,'+dy+'px,0) scale('+scale+')';
}
const reveal = (t,key,span=.42) => out(range(t,cues[key],span));
function pop(t,id,cue=id,span=.42,distance=16){
  const p = reveal(t,cue,span);
  pose($(id),p,0,distance*(1-p),lerp(.98,1,p));
}
const sets = [
  ['integrate',sceneStarts.connect,120,149,1,1],
  ['automate',sceneStarts.comment,116,151,1,1],
  ['conversation',sceneStarts.thread,107,149,1.025,1.025],
  ['booking',sceneStarts.booking,122,156,.988,.988],
  ['inbox',sceneStarts.inbox,114,155,1,1],
  ['lead',sceneStarts.lead,118,155,1,1],
  ['settings',sceneStarts.knowledge,120,152,1,1],
  ['improve',sceneStarts.improve,124,156,.99,.99],
  ['install',sceneStarts.install,106,147,1.027,1.027],
  ['vigento',sceneStarts.vigento,117,152,1,1],
];
const plateExit = sceneStarts.closing;
const noteSequence = Object.keys(content);
const thread = $('thread');
let stops = [];
let heights = [];
let viewportHeight = 0;
let listeningTop = 0;

function measureThread(){
  viewportHeight = thread.parentElement.clientHeight;
  const top = thread.getBoundingClientRect().top;
  heights = messages.map(([id])=>$(id).offsetHeight);
  listeningTop = $('dm-voice').offsetTop+$('dm-voice').offsetHeight+14;
  stops = messages.map(([id],i)=>Math.max(0,$(id).offsetTop+heights[i]+24-viewportHeight));
  if(!top && !viewportHeight) throw Error('Conversation could not be measured');
}
function renderThread(t){
  let offset = 0;
  for (const [i,[id,side]] of messages.entries()) {
    const p = reveal(t,id,.48);
    pose($(id),p,side==='in'?17*(1-p):-14*(1-p),19*(1-p));
    offset += (stops[i]-(stops[i-1]||0))*inOut(range(t,cues[id],.62));
  }
  thread.style.transform='translate3d(0,'+(-offset)+'px,0)';
  const listeningStart = cues['dm-voice']+.62;
  const listeningEnd = cues['dm-text'];
  const listening = out(range(t,listeningStart,.32))*(1-inOut(range(t,listeningEnd-.19,.28)));
  const prompt = $('voice-listening');
  pose(prompt,listening,0,listeningTop-offset+12*(1-listening));
  for(const [i,dot] of [...prompt.querySelectorAll('i')].entries()){
    dot.style.opacity=String(.40+.6*(.5+.5*Math.sin(t*7-i*.9)));
  }
  const active = t >= cues['dm-voice'] && t < cues['dm-text']+.24;
  const waveProgress = range(t,cues['dm-voice']+.12,cues['dm-text']-cues['dm-voice']);
  for(const [i,bar] of [...$('wave').children].entries()){
    const playing = active && i/26<waveProgress;
    bar.style.opacity = playing?'1':'.54';
    bar.style.transform = 'scaleY('+(playing?(1+.17*Math.sin(t*14+i*.69)):1)+')';
  }
  const plans = [['dm-select','همین کت مشکی سایز ۴۰ رو می‌خوام.',.91],['dm-confirm','تأیید می‌کنم.',.49]];
  const typing = plans.find(([cue,,s])=>t>=cues[cue]-s&&t<cues[cue]);
  const field = $('composer-field');
  field.classList.toggle('is-typing',Boolean(typing));
  field.textContent = typing?typing[1].slice(0,Math.ceil(range(t,cues[typing[0]]-typing[2],typing[2])*typing[1].length))+'▏':'پیام بنویس…';
}

function renderPlate(t){
  let position = [655,744,.63,.077];
  for(const [id,at,x,y,sx,sy] of sets){
    const progress = inOut(range(t,at,.73));
    position = position.map((value,i)=>lerp(value,[x,y,sx,sy][i],progress));
    const next=sets[sets.findIndex(([key])=>key===id)+1]?.[1]??plateExit;
    const opacity=out(range(t,at+.2,.44))*(1-inOut(range(t,next,.32)));
    pose($(id),opacity,0,12*(1-opacity));
  }
  const exit = inOut(range(t,plateExit,.57));
  position=position.map((value,i)=>lerp(value,[737,443,.54,.10][i],exit));
  const [x,y,sx,sy]=position;
  const plate=$('plate');
  plate.style.opacity=String(out(range(t,sceneStarts.connect,.22))*(1-out(range(t,plateExit+.18,.37))));
  plate.style.transform='translate3d('+x+'px,'+y+'px,0) scale('+sx+','+sy+')';
}
function renderNotes(t){
  for(const [i,key] of noteSequence.entries()){
    const p=out(range(t,sceneStarts[key]+.20,.48));
    const q=inOut(range(t,sceneStarts[noteSequence[i+1]]??plateExit,.30));
    pose($('note-'+key),p*(1-q),0,31*(1-p)-14*q);
  }
}
function renderIntro(t){
  const intro = out(range(t,.04,.78));
  const exit = inOut(range(t,sceneStarts.connect-.07,.72));
  const close = inOut(range(t,plateExit+.05,.69));
  const branded = inOut(range(t,cues.intro-.16,.62));
  const promise = inOut(range(t,cues.promise,.66));
  const logoX = lerp(645,115,exit*(1-close));
  const logoY = lerp(lerp(263,105,branded),46,exit*(1-close));
  const finalLogoY = lerp(logoY,237,close)-24*(1-intro);
  const logoScale = lerp(lerp(.92,1,intro),.307,exit*(1-close));
  pose($('logo'),intro,logoX,finalLogoY,logoScale);
  const glow = intro*(1-exit)+close*.88;
  $('orbit').style.opacity = String(glow);
  $('lantern').style.opacity = String(glow);
  $('mast').style.opacity = String(exit*(1-close));
  const hello = out(range(t,cues.welcome,.58))*(1-branded);
  pose($('greeting'),hello,0,30*(1-hello)-29*branded);
  const explain = out(range(t,cues.intro,.58));
  pose($('intro-title'),explain*(1-promise),0,30*(1-explain)-47*promise,1-.025*promise);
  pose($('promise'),promise*(1-exit),0,29*(1-promise)-20*exit);
  const tray = out(range(t,cues['promise-tray'],.81));
  const trayMask = (1-tray)*43;
  $('promise-tray').style.clipPath = 'inset(0 '+trayMask+'% 0 '+trayMask+'% round 100px)';
  pose($('promise-tray'),tray,0,12*(1-tray),lerp(.88,1,tray));
  const polish = inOut(range(t,cues['promise-pro']-.20,1.35));
  $('promise-gloss').style.transform = 'translateX('+lerp(-500,1440,polish)+'px) skewX(-19deg)';
  for(const [id,key] of [['pro-word','promise-pro'],['smart-word','promise-smart'],['be-word','promise-be']]){
    const p = reveal(t,key,.61);
    pose($(id),p,0,105*(1-p));
  }
  ['chip-answer','chip-pay','chip-rules'].forEach((key,i)=>{
    const p = reveal(t,key,[.54,.44,.38][i]);
    pose($('chip-'+i),p*(1-exit),0,lerp(18,0,p)-20*exit+16*promise,lerp(.94,1,p));
  });
  pose($('close').querySelector('h1'),out(range(t,plateExit+.32,.56)),0,30*(1-close));
}
function renderDetails(t){
  const connected=reveal(t,'connect-done',.38);
  pose($('connect-action'),1-connected,0,-8*connected,lerp(1,.92,connected));
  pose($('connected'),connected,0,8*(1-connected),lerp(.94,1,connected));
  pose($('integrated'),connected,0,12*(1-connected));
  for(const [id,event] of [['integration-comment','rule-comment'],['integration-story','rule-story']]){
    const p=reveal(t,event);
    pose($(id),.46+.54*p,0,7*(1-p));
    $(id).classList.toggle('is-active',p>.67);
  }
  const sail = inOut(range(t,cues.jump+.04,.94));
  const mail = out(range(t,cues.jump+.04,.29))*(1-inOut(range(t,cues['dm-start']-.17,.44)));
  pose($('bridge'),mail,lerp(175,563,sail),lerp(650,264,sail)-105*Math.sin(sail*Math.PI),lerp(.93,1.04,sail));
  const typing=range(t,cues['type-comment'],cues['send-comment']-cues['type-comment']);
  setMarkup($('sample-comment'),icon('chat')+(typing>0?'سارا · '+('«لینک»'.slice(0,Math.ceil(typing*6))):'کامنت‌ها'));
  pop(t,'trigger','trigger',.44,9);
  pop(t,'rule-divider','trigger',.28,4);
  pop(t,'jump','jump',.37,10);
  const consulted=reveal(t,'product-facts',.48);
  pose($('note-consult').querySelector('.tags'),consulted,0,16*(1-consulted));
  const site=reveal(t,'site-open',.46)*(1-inOut(range(t,sceneStarts.card,.30)));
  pose($('site-pay'),site,0,24*(1-site),.96+.04*site);
  $('site-pay').classList.toggle('payment-focused',t>=cues['site-go']&&t<sceneStarts.card);
  const bank=reveal(t,'bank-open',.45)*(1-inOut(range(t,sceneStarts.track,.42)));
  pose($('card-pay'),bank,0,24*(1-bank),.96+.04*bank);
  const ok=reveal(t,'bank-ok',.45);
  pose($('bank-dots'),1-ok,0,-8*ok);
  pose($('bank-ok'),ok,0,lerp(8,-42,ok));
  const booking=reveal(t,'days',.42);
  pose($('hours'),booking,0,13*(1-booking));
  $('day-3').classList.toggle('on',t>=cues.days);
  $('book-slot').classList.toggle('on',t>=cues['book-slot']);
  pop(t,'book-done');
  const row = reveal(t,'inbox-rows');
  for(const id of ['inbox-sara','inbox-niloofar','inbox-elham']) pose($(id),row,0,11*(1-row));
  pop(t,'handoff-card','handoff',.50);
  const mode = inOut(range(t,sceneStarts.behavior,.45));
  $('tab-knowledge').classList.toggle('on',mode<.5);
  $('tab-behavior').classList.toggle('on',mode>=.5);
  pose($('kb'),1-mode,-18*mode);
  pose($('behavior'),mode,21*(1-mode));
  for (const id of ['kb-site','kb-file','kb-faq','tone','hello','escalate']) {
    const p=reveal(t,id,.44);
    pose($(id),.40+.60*p,0,8*(1-p));
    $(id).classList.toggle('is-active',p>.65);
  }
}

function renderSwitch(id,t,key=id){
  const p=key==='always'?1:reveal(t,key,.30);
  $(id).style.background=p>.5?'#507255':'#e6ded2';
  $(id).style.borderColor=p>.5?'#507255':'#d7c7ae';
  $(id).firstElementChild.style.transform='translateX('+23*p+'px)';
}
function renderDock(id,t,key,exitAt){
  const p=reveal(t,key,.48);
  const q=inOut(range(t,exitAt,.32));
  pose($(id),p*(1-q),0,23*(1-p)-14*q,lerp(.96,1,p));
}
function renderAddedPanels(t){
  renderDock('woo-sync',t,'sync-open',sceneStarts.voice);
  for(const id of ['sync-stock','sync-price','sync-spec','sync-orders']){
    const row=$(id);
    const p=reveal(t,id,.44);
    pose(row.querySelector('.sync-from'),1-p,0,-12*p);
    pose(row.querySelector('.sync-to'),p,0,11*(1-p));
  }
  pop(t,'sync-done','sync-done',.38,11);
  renderDock('track-order',t,'track-open',sceneStarts.booking);
  pop(t,'track-live','track-live',.46,11);
  $('track-live').classList.toggle('done',t>=cues['track-live']+.28);
  pop(t,'track-sync','track-sync',.39,11);

  renderSwitch('lead-switch',t);
  for(const id of ['lead-name','lead-phone','crm-contact','crm-success']) pop(t,id,id,.44,8);
  const sent=reveal(t,'lead-send',.45);
  pose($('lead-arrow'),sent,12*(1-sent),0);
  $('lead-submit').style.background=sent>.58?'#506c50':'#30261a';

  renderSwitch('review-switch',t);
  const review=out(range(t,cues['review-state'],.44));
  const progress=inOut(range(t,cues['review-state'],cues['review-suggestion']-cues['review-state']));
  pose($('review-state'),review);
  $('review-line').style.transform='scaleX('+progress+')';
  $('review-status').textContent=progress>=.994?'مرور شد':'مرور گفتگوها';
  pop(t,'review-source','review-source',.52,15);
  pop(t,'review-suggestion','review-suggestion',.55,17);

  const preferences=inOut(range(t,sceneStarts.alerts,.52));
  pose($('install-view'),1-preferences,-26*preferences);
  pose($('preferences-view'),preferences,26*(1-preferences));
  const installed=reveal(t,'install-action',.57);
  const permitted=reveal(t,'enable-action',.44);
  pose($('device-phone'),1,0,9*(1-installed),lerp(.97,1,installed));
  pose($('desktop'),1,0,6*(1-installed),lerp(.98,1,installed));
  pose($('device-phone').querySelector('.app-mark'),lerp(.45,1,installed),0,5*(1-installed));
  const install=$('install-action');
  install.classList.toggle('done',installed>.6);
  setMarkup(install,installed>.6?icon('check')+'برنامه نصب شد':icon('plus')+'نصب برنامه');
  const enable=$('enable-action');
  enable.classList.toggle('done',permitted>.6);
  setMarkup(enable,permitted>.6?icon('check')+'اعلان‌ها روشن شد':icon('bell')+'روشن کردن اعلان‌ها');
  pop(t,'desktop-toast','desktop-toast',.48,15);
  pop(t,'phone-toast','phone-toast',.46,15);
  for(const id of ['pref-orders','pref-pay','pref-book']) renderSwitch(id,t,'always');
  renderSwitch('pref-handoff',t);

  for(const id of ['vigento-query','vigento-answer','vigento-change','vigento-proposal']) pop(t,id,id,.42,12);
}

function renderCaption(t){
  const current=captions.find(caption=>t>=caption.time&&t<caption.until);
  const label=$('caption-text');
  label.textContent=current?.text??'';
  const opacity=current?out(range(t,current.time,.13))*(1-inOut(range(t,current.until-.13,.13))):0;
  pose(label,opacity,0,5*(1-opacity));
}
window.seek=t=>{
  renderIntro(t);
  renderPlate(t);
  renderNotes(t);
  renderThread(t);
  renderDetails(t);
  renderAddedPanels(t);
  renderCaption(t);
};
function selectFrames(){
  const selected=new Set([0,frames-1]);
  const add=(start,stop,step=1)=>{
    const begin=Math.max(0,Math.floor(start*fps));
    const end=Math.min(frames-1,Math.ceil(stop*fps));
    for(let f=begin;f<=end;f+=step) selected.add(f);
    selected.add(end);
  };
  add(0,1.21);
  for(const time of Object.values(sceneStarts))add(time-.10,time+.89);
  for(const [key,time] of Object.entries(cues)){
    if(['type-comment','send-comment'].includes(key)) add(time-.07,time+.46);
    else add(time-.04,time+.55);
  }
  for(const item of captions){add(item.time-.035,item.time+.16);add(item.until-.16,item.until+.035);}
  add(cues['dm-voice'],cues['dm-text']+.25,2);
  add(cues.jump,cues['dm-start']+.30);
  add(cues['promise-tray'],cues['promise-pro']+1.45);
  add(cues['review-state'],cues['review-suggestion']+.15,2);
  add(cues['dm-select']-.92,cues['dm-select']);
  add(cues['dm-confirm']-.50,cues['dm-confirm']);
  return [...selected].sort((a,b)=>a-b);
}
window.audit=()=>{
  if(stops.some((value,i)=>i&&value<stops[i-1]))throw Error('Non-monotonic thread scroll');
  const row=document.querySelector('#catalogue-native article');
  if(!row || document.querySelectorAll('#catalogue-native article').length!==2)throw Error('Product preview should contain two native cards');
  const maxCaption = Math.max(...captions.map(c=>{
    $('caption-text').textContent=c.text;
    return $('caption-text').clientWidth;
  }));
  if(maxCaption>1620)throw Error('Caption exceeds horizontal safe area');
  return {keys:window.keyFrames.length,summary:cues['dm-summary'],confirm:cues['dm-confirm'],pay:cues['dm-link'],maxCaption,chatStops:stops,viewportHeight,heights};
};
window.ready=Promise.all([
  document.fonts.ready,
  ...[...document.images].map(img=>img.decode().catch(()=>{throw Error('Missing image: '+img.src);}))
]).then(()=>{
  measureThread();
  window.keyFrames=selectFrames();
  window.seek(0);
  return true;
});
