import { readFile, stat, writeFile, rename } from 'node:fs/promises';
import { parseEnv } from 'node:util';
import { films } from './story.mjs';

const model='google/gemini-3.8-flash-tts';
const voice='Algieba';
const instructions='Read this as one continuous take of a Persian product walkthrough. Use a native Tehran Persian accent and maintain the same grounded, warm male narrator and pitch from the first word to the last. Speak clearly at a gently brisk, friendly onboarding pace. Link the sentences with short natural pauses. Never switch character or perform a dialogue voice when reading quoted examples. Read all the provided Persian text, exactly, without adding an intro, music or sound effects. Pronounce ویجِنت as VEE-jent, and ویجِنتو as VEE-jent-oh. Read CRM as See-Ar-Em in Persian.';
const key = process.env.OPENROUTER_API_KEY || parseEnv(await readFile('.env','utf8').catch(() => '')).OPENROUTER_API_KEY;
if(!key)throw Error('Missing configured speech key');
const wanted=process.argv.slice(2);
const queue=Object.entries(films).filter(([channel])=>!wanted.length||wanted.includes(channel));
async function take(film) {
 const file=new URL('voice/'+film.channel+'.pcm',import.meta.url);
 if((await stat(file).catch(()=>null))?.size>2_800_000)return;
 const input=film.lines.map(([,text])=>text).join(' ');
 const response=await fetch('https://openrouter.ai/api/v1/audio/speech',{
  method:'POST', redirect:'error', signal:AbortSignal.timeout(140000),
  headers:{'Content-Type':'application/json',Authorization:'Bearer '+key},
  body:JSON.stringify({model,voice,input,instructions,response_format:'pcm'}),
 });
 const type=response.headers.get('content-type')??'';
 if(!response.ok||!type.includes('audio/pcm')||!type.includes('rate=24000')||!type.includes('channels=1')){
   throw new Error(film.channel+' speech HTTP '+response.status+' '+type);
 }
 const bytes=Buffer.from(await response.arrayBuffer());
 if(bytes.length<2_800_000||bytes.length%2)throw Error(film.channel+' speech too short or incomplete');
 const temp=new URL(file.toString()+'.tmp');
 await writeFile(temp,bytes);
 await rename(temp,file);
 console.log(film.channel,(bytes.length/48000).toFixed(2),'seconds in one take ·',input.split(/\s+/).length,'words');
}
await Promise.all(Array.from({length:Math.min(2,queue.length)},async()=>{
 while(queue.length){
   const [,film]=queue.shift();
   try{await take(film);}
   catch(error){console.error(error.message);process.exitCode=1;}
 }
}));
