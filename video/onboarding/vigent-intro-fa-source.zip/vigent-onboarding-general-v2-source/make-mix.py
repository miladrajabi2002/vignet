from pathlib import Path
from functools import lru_cache
import json
import re
import subprocess
import sys
import tempfile

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

rate = 48_000
timeline = json.loads(Path('timing.json').read_text())

def ffmpeg(*args):
    return subprocess.run(['ffmpeg','-nostdin','-hide_banner','-y',*map(str,args)],
                          capture_output=True, check=True)

def level(*args):
    out = ffmpeg(*args, '-af','loudnorm=I=-16:TP=-1.5:LRA=8:print_format=json','-f','null','-')
    return json.loads(re.findall(r'\{[^{}]+"input_i"[^{}]+\}', out.stderr.decode(errors='replace'))[-1])

def grid(duration):
    return np.arange(round(duration * rate),dtype=np.float32) / rate

def tune(key):
    return 440 * 2 ** ((key - 69) / 12)

def pluck(key, length, decay=.27, attack=.017):
    t = grid(length)
    angle = 2 * np.pi * tune(key) * t
    envelope = np.minimum(t / attack, 1) * np.exp(-t / decay) * np.minimum((length - t) / .064, 1)
    return envelope * (np.sin(angle) + .18 * np.sin(2 * angle + .18) * np.exp(-t / .19))

def pad(key, phase, length=3.02):
    t = grid(length)
    f = tune(key)
    envelope = np.minimum(t/.72,1) * np.clip((length-t)/.59,0,1)
    return envelope ** 1.4 * (np.sin(2*np.pi*f*t+phase) + .24*np.sin(2*np.pi*(f+.56)*t-phase/2))

def place(track, when, wave, pan=0):
    start = round(when * rate)
    count = min(len(wave), len(track) - start)
    if count > 0:
        track[start:start+count] += wave[:count,None] * np.sqrt((1 + np.array([-pan,pan]))/2)

@lru_cache(maxsize=28)
def voice_pcm(source):
    pcm = ['-f','s16le','-ar','24000','-ac','1','-i',source]
    scan = ffmpeg(*pcm,'-af','highpass=f=66,loudnorm=I=-18:TP=-1.5:LRA=8:print_format=json','-f','null','-')
    decoded = scan.stderr.decode(errors='replace')
    measure = json.loads(re.findall(r'\{[^{}]+"input_i"[^{}]+\}',decoded)[-1])
    gain = -18.3 - float(measure['input_i'])
    wav = ffmpeg('-loglevel','error',*pcm,'-af',
                 f'highpass=f=66,volume={gain:.2f}dB,alimiter=limit=0.78:attack=5:release=54:level=0:latency=1',
                 '-ar',rate,'-f','f32le','-')
    return np.frombuffer(wav.stdout,dtype='<f4').copy()

chords = [
    (45,52,60,64),
    (41,48,57,64),
    (48,55,62,64),
    (43,50,59,62),
]
click_clock = grid(.117)
click = np.sin(2*np.pi*(565*click_clock-810*click_clock**2)) * np.exp(-click_clock/.019)
click *= np.minimum(click_clock/.0045,1)
noise_filter = butter(2,[155,2250],btype='bandpass',fs=rate,output='sos')

def build(episode):
    number = 11
    rng = np.random.default_rng(17+number)
    time = grid(episode['duration'])
    bed = np.zeros((len(time),2),dtype=np.float32)
    effects = np.zeros_like(bed)
    speech = np.zeros(len(time),dtype=np.float32)
    duck = np.zeros(len(time),dtype=np.float32)

    for scene in episode['scenes']:
        wave = voice_pcm(Path('voice') / scene['track']).copy()
        ramp = np.linspace(0,1,310)
        wave[:len(ramp)] *= ramp
        wave[-len(ramp):] *= ramp[::-1]
        start = round(scene['voiceStart']*rate)
        stop = start + len(wave)
        speech[start:stop] += wave
        activity = np.clip((time-scene['voiceStart']+.22)/.40,0,1)
        activity *= np.clip((stop/rate+.27-time)/.45,0,1)
        duck = np.maximum(duck,activity)

    for bar in range(int(len(time)/rate/2.16)+1):
        at = .045 + bar*2.16
        close = at > episode['closeAt']
        chord = chords[0 if close else bar%len(chords)]
        for i,key in enumerate(chord):
            place(bed,at,.077*pad(key,1.3*i),[0,.36,-.52,.49][i])
        place(bed,at,.33*pluck(chord[0]-12,1.55,decay=.52,attack=.041))
        cells = [(.08,2,-.42),(.67,3,.39),(1.19,1,-.26),(1.85,3,.26)]
        if close or bar % 4 == 3:
            cells = cells[:2]
        for offset,tone,pan in cells:
            key = .208*pluck(chord[tone],1.10,decay=.29)
            place(bed,at+offset,key,pan)
            place(bed,at+offset+.163,key*.109,-pan)

    def bell(at,pitches,gains,pan=.16,decay=.20):
        for k,(key,amplitude) in enumerate(zip(pitches,gains)):
            place(effects,at+.089*k,amplitude*pluck(key,.68,decay,.009),pan if k%2==0 else -pan)

    def sweep(at,length,amount):
        t = grid(length)
        sound = sosfilt(noise_filter,rng.standard_normal(len(t)))
        place(effects,at,amount*sound*np.sin(np.pi*t/length)**2,-.13)

    for item in episode['events']:
        at = item['time'] + .031
        sound = item['sound']
        if sound == 'send':
            place(effects,at,.069*click,.19)
        elif sound == 'tap':
            place(effects,at,.042*click,-.11)
        elif sound == 'tick':
            place(effects,at-.012,.093*click,.14)
            key = 74 + (round(at*10) % 5)
            place(effects,at+.021,.031*pluck(key,.35,.093,.008),-.16)
        elif sound == 'whoosh':
            sweep(at,.38,.076)
        elif sound == 'open':
            bell(at,[69,76,81],[.061,.045,.026],.14,.28)
        elif sound == 'reply':
            bell(at,[79,86],[.055,.026],-.20,.16)
        elif sound == 'card':
            sweep(at,.26,.038)
            bell(at+.05,[76],[.036],-.19,.15)
        elif sound == 'done':
            bell(at,[76,81,85],[.072,.060,.037],.13,.27)

    fade = np.clip((episode['duration']-time)/1.06,0,1)**1.5
    mixed = bed * (.121-.062*duck)[:,None] + effects + speech[:,None]/np.sqrt(2)
    mixed *= fade[:,None]
    if not np.isfinite(mixed).all():
        raise ValueError('Nonfinite mix for ' + episode['id'])
    with tempfile.NamedTemporaryFile(suffix='.wav',dir='mixes') as temp:
        wavfile.write(temp.name,rate,mixed.astype(np.float32))
        gain = -16.0 - float(level('-i',temp.name)['input_i'])
        name = Path('mixes') / (episode['id']+'.m4a')
        ffmpeg('-v','error','-i',temp.name,'-af',
               f'volume={gain:.3f}dB,alimiter=limit=0.84:attack=5:release=55:level=0:latency=1',
               '-c:a','aac','-b:a','224k',name)
        measured = level('-i',name)
        if float(measured['input_tp']) >= -1.05:
            raise ValueError(f"True peak exceeds target in {episode['id']}")
        print(episode['id'], measured['input_i'], 'LUFS', measured['input_tp'], 'dBTP', flush=True)

for item in sys.argv[1:] or timeline:
    build(timeline[item])
